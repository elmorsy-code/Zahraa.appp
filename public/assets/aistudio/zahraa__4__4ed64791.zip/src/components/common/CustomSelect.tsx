import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check, Search } from 'lucide-react';

export interface SelectOption<T = string | number> {
  value: T;
  label: string;
  icon?: React.ReactNode;
  badge?: string;
}

interface CustomSelectProps<T = string | number> {
  options: SelectOption<T>[];
  value: T;
  onChange: (value: T) => void;
  placeholder?: string;
  className?: string;
  buttonClassName?: string;
  menuClassName?: string;
  size?: 'sm' | 'md';
  variant?: 'default' | 'pill' | 'subtle';
  showSearch?: boolean;
  disabled?: boolean;
  align?: 'right' | 'left';
  direction?: 'down' | 'up' | 'auto';
  prefix?: React.ReactNode;
}

export function CustomSelect<T extends string | number>({
  options,
  value,
  onChange,
  placeholder = 'اختر...',
  className = '',
  buttonClassName = '',
  menuClassName = '',
  size = 'md',
  variant = 'default',
  showSearch = false,
  disabled = false,
  align = 'right',
  direction = 'auto',
  prefix,
}: CustomSelectProps<T>) {
  const [isOpen, setIsOpen] = useState(false);
  const [actualDirection, setActualDirection] = useState<'down' | 'up'>(
    direction === 'up' ? 'up' : 'down'
  );
  const [searchQuery, setSearchQuery] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Recalculate direction on open
  useEffect(() => {
    if (isOpen) {
      if (direction === 'up') {
        setActualDirection('up');
      } else if (direction === 'down') {
        setActualDirection('down');
      } else {
        // Auto-detect based on screen space
        if (containerRef.current) {
          const rect = containerRef.current.getBoundingClientRect();
          const spaceBelow = window.innerHeight - rect.bottom;
          if (spaceBelow < 240 && rect.top > 200) {
            setActualDirection('up');
          } else {
            setActualDirection('down');
          }
        }
      }
    }
  }, [isOpen, direction]);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };
    if (isOpen) {
      document.addEventListener('keydown', handleKeyDown);
    }
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  // Focus search input when opened
  useEffect(() => {
    if (isOpen && showSearch && searchInputRef.current) {
      setTimeout(() => searchInputRef.current?.focus(), 50);
    }
    if (!isOpen) {
      setSearchQuery('');
    }
  }, [isOpen, showSearch]);

  const selectedOption = options.find((opt) => opt.value === value);

  // Filter options if search enabled
  const filteredOptions = showSearch && searchQuery.trim()
    ? options.filter((opt) =>
        opt.label.toLowerCase().includes(searchQuery.toLowerCase().trim())
      )
    : options;

  // Base sizing
  const sizeClasses =
    size === 'sm'
      ? 'px-3 py-1.5 text-xs rounded-xl'
      : 'px-3.5 py-2 text-xs sm:text-sm rounded-xl';

  // Variant styling for trigger button
  let variantClasses = 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-50';
  if (variant === 'pill') {
    variantClasses = 'bg-slate-50 border border-slate-200 text-slate-700 hover:bg-slate-100 shadow-2xs';
  } else if (variant === 'subtle') {
    variantClasses = 'bg-transparent border border-transparent text-slate-700 hover:bg-slate-100';
  }

  return (
    <div
      ref={containerRef}
      className={`relative inline-block text-right ${className}`}
      dir="rtl"
    >
      {/* Custom Trigger Button */}
      <button
        type="button"
        disabled={disabled}
        onClick={() => setIsOpen((prev) => !prev)}
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        className={`group flex items-center justify-between gap-2.5 font-bold transition-all cursor-pointer shadow-2xs select-none disabled:opacity-50 disabled:cursor-not-allowed ${sizeClasses} ${variantClasses} ${buttonClassName}`}
      >
        <div className="flex items-center gap-2 truncate">
          {prefix && <span className="shrink-0">{prefix}</span>}
          {selectedOption?.icon && <span className="shrink-0">{selectedOption.icon}</span>}
          <span className="truncate">
            {selectedOption ? selectedOption.label : placeholder}
          </span>
          {selectedOption?.badge && (
            <span className="text-[10px] font-black px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
              {selectedOption.badge}
            </span>
          )}
        </div>

        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform duration-200 ${
            isOpen ? 'rotate-180 text-blue-600' : 'group-hover:text-slate-600'
          }`}
        />
      </button>

      {/* Custom Dropdown Menu Popover */}
      {isOpen && (
        <div
          role="listbox"
          className={`absolute ${
            align === 'left' ? 'left-0' : 'right-0'
          } ${
            actualDirection === 'up'
              ? 'bottom-full mb-1.5 origin-bottom'
              : 'top-full mt-1.5 origin-top'
          } min-w-[160px] max-w-xs w-max bg-white rounded-2xl shadow-2xl border border-slate-200/90 py-1.5 z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden text-right ${menuClassName}`}
        >
          {/* Optional Search bar inside dropdown */}
          {showSearch && options.length > 5 && (
            <div className="p-2 border-b border-slate-100">
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-2.5 top-1/2 -translate-y-1/2" />
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="بحث في الخيارات..."
                  className="w-full pr-8 pl-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>
          )}

          {/* Options List */}
          <div className="max-h-60 overflow-y-auto py-0.5 scrollbar-thin">
            {filteredOptions.length === 0 ? (
              <div className="py-4 px-3 text-center text-xs text-slate-400 font-medium">
                لا توجد نتائج مطابقة
              </div>
            ) : (
              filteredOptions.map((opt) => {
                const isSelected = opt.value === value;

                return (
                  <button
                    key={String(opt.value)}
                    type="button"
                    role="option"
                    aria-selected={isSelected}
                    onClick={() => {
                      onChange(opt.value);
                      setIsOpen(false);
                    }}
                    className={`w-full flex items-center justify-between gap-3 px-3.5 py-2 text-xs sm:text-sm font-bold transition-colors cursor-pointer text-right ${
                      isSelected
                        ? 'bg-blue-50 text-blue-900 font-black'
                        : 'text-slate-700 hover:bg-slate-50 hover:text-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      {opt.icon && <span className="shrink-0">{opt.icon}</span>}
                      <span className="truncate">{opt.label}</span>
                      {opt.badge && (
                        <span className="text-[10px] font-black px-1.5 py-0.2 rounded-md bg-emerald-100 text-emerald-800">
                          {opt.badge}
                        </span>
                      )}
                    </div>

                    {isSelected && (
                      <Check className="w-3.5 h-3.5 text-blue-600 shrink-0" />
                    )}
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}
