import React, { useEffect, useState } from 'react';
import { CheckCircle2, AlertCircle, AlertTriangle, Info, X } from 'lucide-react';
import { toast, ToastItem, ToastType } from '../../lib/toast';

const TOAST_STYLES: Record<
  ToastType,
  {
    bg: string;
    border: string;
    text: string;
    titleColor: string;
    icon: React.ReactNode;
    barColor: string;
  }
> = {
  success: {
    bg: 'bg-emerald-950/90 text-white backdrop-blur-md',
    border: 'border-emerald-600/40',
    text: 'text-emerald-100',
    titleColor: 'text-emerald-300',
    icon: <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />,
    barColor: 'bg-emerald-400',
  },
  error: {
    bg: 'bg-rose-950/90 text-white backdrop-blur-md',
    border: 'border-rose-600/40',
    text: 'text-rose-100',
    titleColor: 'text-rose-300',
    icon: <AlertCircle className="w-5 h-5 text-rose-400 shrink-0" />,
    barColor: 'bg-rose-400',
  },
  warning: {
    bg: 'bg-amber-950/90 text-white backdrop-blur-md',
    border: 'border-amber-600/40',
    text: 'text-amber-100',
    titleColor: 'text-amber-300',
    icon: <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0" />,
    barColor: 'bg-amber-400',
  },
  info: {
    bg: 'bg-slate-900/90 text-white backdrop-blur-md',
    border: 'border-blue-500/40',
    text: 'text-slate-200',
    titleColor: 'text-blue-300',
    icon: <Info className="w-5 h-5 text-blue-400 shrink-0" />,
    barColor: 'bg-blue-400',
  },
};

export const ToastContainer: React.FC = () => {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  useEffect(() => {
    return toast.subscribe((updated) => {
      setToasts(updated);
    });
  }, []);

  if (toasts.length === 0) return null;

  return (
    <div
      dir="rtl"
      className="fixed top-4 left-4 z-50 flex flex-col gap-2.5 max-w-sm sm:max-w-md w-full pointer-events-none"
      aria-live="polite"
    >
      {toasts.map((t) => {
        const style = TOAST_STYLES[t.type] || TOAST_STYLES.info;

        return (
          <div
            key={t.id}
            role="alert"
            className={`pointer-events-auto relative overflow-hidden rounded-2xl border ${style.border} ${style.bg} p-3.5 sm:p-4 shadow-2xl transition-all animate-in fade-in slide-in-from-top-3 duration-200 flex items-start gap-3`}
          >
            <div className="pt-0.5">{style.icon}</div>

            <div className="flex-1 min-w-0 pr-0.5">
              {t.title && (
                <h4 className={`text-xs sm:text-sm font-black ${style.titleColor} mb-0.5`}>
                  {t.title}
                </h4>
              )}
              <p className={`text-xs sm:text-sm font-bold ${style.text} leading-relaxed`}>
                {t.message}
              </p>
            </div>

            <button
              type="button"
              onClick={() => toast.dismiss(t.id)}
              className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors cursor-pointer shrink-0"
              aria-label="إغلاق التنبيه"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
