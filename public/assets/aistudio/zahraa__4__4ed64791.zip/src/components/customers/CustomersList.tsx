import React, { useState, useEffect, useRef } from 'react';
import {
  Search,
  Plus,
  Users,
  Coins,
  User,
  Trash2,
  Pencil,
  Eye,
  MoreVertical,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Receipt,
  FileSpreadsheet,
} from 'lucide-react';
import { Customer } from '../../types/database';
import { storage } from '../../lib/storage';
import { authService } from '../../lib/auth';
import { ConfirmDeleteModal } from '../common/ConfirmDeleteModal';
import { CustomerModal } from './CustomerModal';
import { CustomerLedgerModal } from './CustomerLedgerModal';
import { CustomerPaymentModal } from './CustomerPaymentModal';
import { CustomSelect } from '../common/CustomSelect';

interface CustomersListProps {
  initialOpenLedger?: boolean;
}

const AVATAR_PALETTE = [
  'bg-[#a855f7]', // purple
  'bg-[#22c55e]', // green
  'bg-[#3b82f6]', // blue
  'bg-[#ec4899]', // pink
  'bg-[#8b5cf6]', // violet
  'bg-[#14b8a6]', // teal
  'bg-[#f97316]', // orange
  'bg-[#0ea5e9]', // sky
  'bg-[#6366f1]', // indigo
  'bg-[#10b981]', // emerald
];

export const CustomersList: React.FC<CustomersListProps> = ({ initialOpenLedger = false }) => {
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [search, setSearch] = useState('');
  const [filterDebtorsOnly, setFilterDebtorsOnly] = useState(initialOpenLedger);
  const [selectedVillage, setSelectedVillage] = useState<string>('all');

  // Pagination state
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState<number>(8);

  // Modals & action menus
  const [customerModalOpen, setCustomerModalOpen] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Customer | null>(null);
  const [selectedLedgerCustomer, setSelectedLedgerCustomer] = useState<Customer | null>(null);
  const [selectedPaymentCustomer, setSelectedPaymentCustomer] = useState<Customer | null>(null);
  const [activeMenuId, setActiveMenuId] = useState<string | null>(null);

  const menuRef = useRef<HTMLDivElement | null>(null);
  const isAdmin = authService.getCurrentUser()?.role === 'admin';
  const canAdd = isAdmin || authService.canAdd();
  const canEdit = isAdmin || authService.canEdit();
  const canDelete = isAdmin || authService.canDelete();
  const canCollect = isAdmin || authService.canCollect();

  useEffect(() => {
    loadCustomers();
    const unsubscribe = storage.subscribe(loadCustomers);
    return () => unsubscribe();
  }, []);

  // Close 3-dots popup on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setActiveMenuId(null);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadCustomers = () => {
    setCustomers(storage.getCustomers());
  };

  // Normalization for robust Arabic searching
  const normalize = (text: string) =>
    (text || '')
      .toLowerCase()
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '')
      .replace(/[أإآٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)))
      .replace(/\s+/g, ' ')
      .trim();

  // Distinct villages for dropdown filter
  const distinctVillages = Array.from(
    new Set(
      customers
        .map((c) => (c.village_or_address || '').trim())
        .filter((v) => v.length > 0)
    )
  );

  // Filtered customer list
  const filtered = customers.filter((c) => {
    const q = normalize(search);
    const haystack = normalize(
      [c.name, c.partner_name, c.code, c.phone, c.village_or_address].filter(Boolean).join(' ')
    );

    const matchesSearch =
      !q ||
      q.split(' ').every((word) => haystack.includes(word)) ||
      haystack.replace(/ /g, '').includes(q.replace(/ /g, ''));

    const matchesDebt = !filterDebtorsOnly || c.current_balance > 0;

    const matchesVillage =
      selectedVillage === 'all' ||
      (c.village_or_address && c.village_or_address.trim() === selectedVillage);

    return matchesSearch && matchesDebt && matchesVillage;
  });

  // Calculate metrics
  const totalRegistered = customers.length;
  const totalCustomerDebt = customers.reduce(
    (sum, c) => sum + Math.max(0, c.current_balance),
    0
  );
  const debtorCustomersCount = customers.filter((c) => c.current_balance > 0).length;

  // Pagination calculation
  const totalPages = Math.max(1, Math.ceil(filtered.length / itemsPerPage));
  const safeCurrentPage = Math.min(currentPage, totalPages);
  const startIndex = (safeCurrentPage - 1) * itemsPerPage;
  const paginatedCustomers = filtered.slice(startIndex, startIndex + itemsPerPage);
  const fromCount = filtered.length === 0 ? 0 : startIndex + 1;
  const toCount = Math.min(startIndex + itemsPerPage, filtered.length);

  const getAvatarBg = (idx: number) => {
    return AVATAR_PALETTE[idx % AVATAR_PALETTE.length];
  };

  const formatNumberWithCurrency = (amount: number) => {
    return `${Math.round(amount).toLocaleString('en-US')} ج.م`;
  };

  return (
    <div className="space-y-4 font-sans text-right" dir="rtl">
      {/* 1. TOP SUMMARY METRIC CARDS (Exact match to uploaded image) */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Card 1: عدد العملاء المدينين (Amber / Gold) */}
        <div className="bg-[#fef8ea] border border-[#fef0cd] rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-2xs transition-all hover:shadow-xs">
          {/* Right Icon Box */}
          <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-[#f59e0b] text-white flex items-center justify-center shadow-xs shrink-0">
            <Users className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          {/* Left Text and Number */}
          <div className="text-left">
            <span className="text-xs sm:text-sm font-bold text-[#b45309] block mb-1">
              عدد العملاء المدينين
            </span>
            <span className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#d97706] tracking-tight tabular-nums block">
              {debtorCustomersCount}
            </span>
          </div>
        </div>

        {/* Card 2: إجمالي المديونيات (Rose / Pink) */}
        <div className="bg-[#fff1f2] border border-[#ffe4e6] rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-2xs transition-all hover:shadow-xs">
          {/* Right Icon Box */}
          <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-[#f43f5e] text-white flex items-center justify-center shadow-xs shrink-0">
            <Coins className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          {/* Left Text and Number */}
          <div className="text-left">
            <span className="text-xs sm:text-sm font-bold text-[#be123c] block mb-1">
              إجمالي المديونيات
            </span>
            <span className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#e11d48] tracking-tight tabular-nums block" dir="ltr">
              {formatNumberWithCurrency(totalCustomerDebt)}
            </span>
          </div>
        </div>

        {/* Card 3: إجمالي العملاء المسجلين (Mint / Emerald) */}
        <div className="bg-[#f0fdf4] border border-[#dcfce7] rounded-2xl p-4 sm:p-5 flex items-center justify-between shadow-2xs transition-all hover:shadow-xs">
          {/* Right Icon Box */}
          <div className="w-13 h-13 sm:w-14 sm:h-14 rounded-2xl bg-gradient-to-br from-emerald-400 to-teal-500 text-white flex items-center justify-center shadow-xs shrink-0">
            <User className="w-6 h-6 sm:w-7 sm:h-7" />
          </div>
          {/* Left Text and Number */}
          <div className="text-left">
            <span className="text-xs sm:text-sm font-bold text-[#065f46] block mb-1">
              إجمالي العملاء المسجلين
            </span>
            <span className="text-2xl sm:text-3xl lg:text-4xl font-black text-[#059669] tracking-tight tabular-nums block">
              {totalRegistered}
            </span>
          </div>
        </div>
      </div>

      {/* 2. SEARCH & ACTION FILTER BAR (Exact match to uploaded image) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-3 sm:p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Right Search Input */}
        <div className="relative flex-1 max-w-xl">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="ابحث باسم العميل أو رقم التليفون أو القرية أو الكود..."
            className="w-full pr-10 pl-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-400 focus:bg-white transition-all"
          />
        </div>

        {/* Left Controls: Debtors Toggle + Village Dropdown + Add Customer Button */}
        <div className="flex flex-wrap items-center justify-end gap-3 shrink-0">
          {/* Switch toggle for المدينين فقط */}
          <div className="flex items-center gap-2 select-none">
            <span className="text-xs sm:text-sm font-bold text-slate-700">المدينين فقط</span>
            <button
              type="button"
              role="switch"
              aria-checked={filterDebtorsOnly}
              onClick={() => {
                setFilterDebtorsOnly(!filterDebtorsOnly);
                setCurrentPage(1);
              }}
              className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                filterDebtorsOnly ? 'bg-blue-600' : 'bg-slate-300'
              }`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                  filterDebtorsOnly ? '-translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Custom Village Filter Select */}
          <CustomSelect<string>
            value={selectedVillage}
            onChange={(val) => {
              setSelectedVillage(val);
              setCurrentPage(1);
            }}
            options={[
              { value: 'all', label: 'الكل' },
              ...distinctVillages.map((v) => ({ value: v, label: v })),
            ]}
            showSearch={distinctVillages.length > 5}
            size="md"
            variant="default"
            buttonClassName="min-w-[95px] rounded-xl font-bold text-xs sm:text-sm"
          />

          {/* New Customer Button */}
          {canAdd ? (
            <button
              type="button"
              onClick={() => {
                setEditingCustomer(null);
                setCustomerModalOpen(true);
              }}
              className="bg-[#0f2744] hover:bg-[#18395f] active:scale-[0.98] text-white font-bold px-4 sm:px-5 py-2.5 rounded-xl flex items-center gap-2 text-xs sm:text-sm shadow-xs transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة عميل</span>
            </button>
          ) : (
            <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-2 rounded-xl border border-slate-200">
              {authService.getCurrentUser()?.roleNameAr || 'حساب مشرف'}
            </span>
          )}
        </div>
      </div>

      {/* 3. TABLE OF CUSTOMERS (Exact layout, columns, colors & actions) */}
      <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs relative">
        <div className="overflow-x-auto rounded-t-2xl">
          <table className="w-full text-right text-xs sm:text-sm border-collapse min-w-[980px]">
            {/* Table Header: Ice Blue Background #edf4fa */}
            <thead className="bg-[#edf4fa] border-b border-slate-200 text-slate-800 font-extrabold select-none">
              <tr>
                <th className="py-4 px-3 sm:px-4 text-center w-12 text-slate-700">#</th>
                <th className="py-4 px-4 sm:px-5 min-w-[200px]">اسم العميل</th>
                <th className="py-4 px-4 sm:px-5 min-w-[150px]">رقم التليفون</th>
                <th className="py-4 px-4 sm:px-5 min-w-[140px]">القرية</th>
                <th className="py-4 px-3 sm:px-4 min-w-[100px]">الكود</th>
                <th className="py-4 px-4 sm:px-5 min-w-[130px]">المديونية</th>
                <th className="py-4 px-3 sm:px-4 text-center min-w-[110px]">الحالة</th>
                <th className="py-4 px-4 sm:px-5 text-center min-w-[180px]">الإجراءات</th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-100">
              {paginatedCustomers.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-16 text-center text-slate-400">
                    <Users className="w-10 h-10 mx-auto mb-3 stroke-1 text-slate-300" />
                    <p className="text-base font-bold text-slate-600">لا يوجد عملاء يطابقون محددات البحث</p>
                    <p className="text-xs text-slate-400 mt-1">جرّب تغيير عبارة البحث أو إيقاف تصفية المدينين فقط</p>
                  </td>
                </tr>
              ) : (
                paginatedCustomers.map((customer, index) => {
                  const hasDebt = customer.current_balance > 0;
                  const rowNumber = startIndex + index + 1;
                  const avatarColor = getAvatarBg(index);
                  const initialLetter = customer.name ? customer.name.trim().charAt(0) : 'ع';

                  return (
                    <tr
                      key={customer.id}
                      className="hover:bg-slate-50/80 transition-colors group"
                    >
                      {/* 1. Row Index (#) */}
                      <td className="py-3.5 px-3 sm:px-4 text-center font-bold text-slate-500 tabular-nums">
                        {rowNumber}
                      </td>

                      {/* 2. Customer Name with Avatar */}
                      <td className="py-3.5 px-4 sm:px-5">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-9 h-9 rounded-full flex items-center justify-center text-white font-black text-sm shrink-0 shadow-2xs ${avatarColor}`}
                          >
                            {initialLetter}
                          </div>
                          <div className="min-w-0">
                            <span className="font-bold text-slate-900 text-sm sm:text-base block truncate">
                              {customer.name}
                            </span>
                            {customer.partner_name && (
                              <span className="text-[11px] text-emerald-700 font-semibold block truncate">
                                [شريك: {customer.partner_name}]
                              </span>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* 3. Phone Number */}
                      <td className="py-3.5 px-4 sm:px-5 text-slate-700 font-medium text-sm tabular-nums">
                        {customer.phone || '-'}
                      </td>

                      {/* 4. Village */}
                      <td className="py-3.5 px-4 sm:px-5 text-slate-700 font-semibold text-sm">
                        {customer.village_or_address || '-'}
                      </td>

                      {/* 5. Customer Code */}
                      <td className="py-3.5 px-3 sm:px-4 text-slate-700 font-bold text-sm tabular-nums">
                        {customer.code || `C${String(rowNumber).padStart(3, '0')}`}
                      </td>

                      {/* 6. Current Debt */}
                      <td className="py-3.5 px-4 sm:px-5">
                        <span className="font-black text-slate-900 text-sm sm:text-base tabular-nums block" dir="ltr">
                          {formatNumberWithCurrency(customer.current_balance)}
                        </span>
                      </td>

                      {/* 7. Status Badge (مدين / سليم) */}
                      <td className="py-3.5 px-3 sm:px-4 text-center">
                        {hasDebt ? (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#ffe4e6] text-[#e11d48] text-xs font-black shadow-2xs">
                            <span className="w-2 h-2 rounded-full bg-[#e11d48] shrink-0"></span>
                            <span>مدين</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#dcfce7] text-[#16a34a] text-xs font-black shadow-2xs">
                            <span className="w-2 h-2 rounded-full bg-[#16a34a] shrink-0"></span>
                            <span>سليم</span>
                          </span>
                        )}
                      </td>

                      {/* 8. Action Buttons (4 buttons: Delete, Edit, View, More) */}
                      <td className="py-3.5 px-4 sm:px-5 text-center">
                        <div className="flex items-center justify-center gap-2 relative">
                          {/* 1. Delete (Trash) - When allowed */}
                          {canDelete && (
                            <button
                              type="button"
                              onClick={() => setDeleteTarget(customer)}
                              className="p-2 rounded-lg bg-[#ffe4e6] hover:bg-[#fecdd3] text-[#e11d48] transition-colors cursor-pointer shadow-2xs"
                              title="حذف العميل"
                              aria-label="حذف"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          )}

                          {/* 2. Edit (Pencil) - When allowed */}
                          {canEdit && (
                            <button
                              type="button"
                              onClick={() => {
                                setEditingCustomer(customer);
                                setCustomerModalOpen(true);
                              }}
                              className="p-2 rounded-lg bg-[#e0f2fe] hover:bg-[#bae6fd] text-[#0284c7] transition-colors cursor-pointer shadow-2xs"
                              title="تعديل بيانات العميل"
                              aria-label="تعديل"
                            >
                              <Pencil className="w-4 h-4" />
                            </button>
                          )}

                          {/* 3. View Ledger (Solid Blue Eye) */}
                          <button
                            type="button"
                            onClick={() => setSelectedLedgerCustomer(customer)}
                            className="p-2 rounded-lg bg-[#1d4ed8] hover:bg-[#1e40af] text-white transition-colors cursor-pointer shadow-2xs"
                            title="عرض كشف الحساب والعمليات"
                            aria-label="كشف حساب"
                          >
                            <Eye className="w-4 h-4" />
                          </button>

                          {/* 4. Three dots dropdown menu button */}
                          <div className="relative">
                            <button
                              type="button"
                              onClick={() =>
                                setActiveMenuId(activeMenuId === customer.id ? null : customer.id)
                              }
                              className="p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
                              title="خيارات إضافية"
                              aria-label="المزيد"
                            >
                              <MoreVertical className="w-4 h-4" />
                            </button>

                            {/* Dropdown Menu Popover */}
                            {activeMenuId === customer.id && (
                              <div
                                ref={menuRef}
                                className="absolute left-0 mt-1 w-48 bg-white rounded-xl shadow-xl border border-slate-200 py-1.5 z-30 animate-in fade-in zoom-in-95 text-right text-xs font-bold"
                              >
                                {canCollect && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveMenuId(null);
                                      setSelectedPaymentCustomer(customer);
                                    }}
                                    className="w-full flex items-center gap-2 px-3.5 py-2 text-emerald-800 hover:bg-emerald-50 transition-colors cursor-pointer"
                                  >
                                    <Receipt className="w-4 h-4 text-emerald-600" />
                                    <span>سند قبض / تحصيل نقدية</span>
                                  </button>
                                )}

                                <button
                                  type="button"
                                  onClick={() => {
                                    setActiveMenuId(null);
                                    setSelectedLedgerCustomer(customer);
                                  }}
                                  className="w-full flex items-center gap-2 px-3.5 py-2 text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                                >
                                  <FileSpreadsheet className="w-4 h-4 text-blue-600" />
                                  <span>كشف الحساب المفصل</span>
                                </button>

                                {canEdit && (
                                  <button
                                    type="button"
                                    onClick={() => {
                                      setActiveMenuId(null);
                                      setEditingCustomer(customer);
                                      setCustomerModalOpen(true);
                                    }}
                                    className="w-full flex items-center gap-2 px-3.5 py-2 text-slate-700 hover:bg-slate-50 transition-colors cursor-pointer"
                                  >
                                    <Pencil className="w-4 h-4 text-slate-500" />
                                    <span>تعديل بيانات العميل</span>
                                  </button>
                                )}

                                {canDelete && (
                                  <>
                                    <div className="my-1 border-t border-slate-100" />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        setActiveMenuId(null);
                                        setDeleteTarget(customer);
                                      }}
                                      className="w-full flex items-center gap-2 px-3.5 py-2 text-rose-700 hover:bg-rose-50 transition-colors cursor-pointer"
                                    >
                                      <Trash2 className="w-4 h-4 text-rose-600" />
                                      <span>حذف العميل نهائياً</span>
                                    </button>
                                  </>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* 4. FOOTER & PAGINATION BAR (Exact match to uploaded image) */}
        <div className="p-3.5 sm:p-4 border-t border-slate-100 bg-white rounded-b-2xl relative z-20 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs sm:text-sm">
          {/* Right side (in RTL): Items per page select + Counter label */}
          <div className="flex items-center gap-3 text-slate-600 font-bold">
            {/* Custom Items per page dropdown */}
            <CustomSelect<number>
              value={itemsPerPage}
              direction="up"
              onChange={(val) => {
                setItemsPerPage(val);
                setCurrentPage(1);
              }}
              options={[
                { value: 8, label: 'عدد 8' },
                { value: 10, label: 'عدد 10' },
                { value: 15, label: 'عدد 15' },
                { value: 25, label: 'عدد 25' },
                { value: 50, label: 'عدد 50' },
              ]}
              size="sm"
              variant="pill"
              buttonClassName="rounded-xl font-bold text-xs"
            />

            {/* Range counter */}
            <span>
              عرض {fromCount} - {toCount} من {filtered.length} عميل
            </span>
          </div>

          {/* Left side (in RTL): Pagination Buttons */}
          <div className="flex items-center gap-1.5">
            {/* Previous Page Button (<) */}
            <button
              type="button"
              disabled={safeCurrentPage <= 1}
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              className="p-1.5 sm:p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
              title="الصفحة السابقة"
              aria-label="السابق"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Dynamic Page Numbers */}
            {(() => {
              const maxButtons = 5;
              let start = Math.max(1, safeCurrentPage - 2);
              let end = Math.min(totalPages, start + maxButtons - 1);
              if (end - start + 1 < maxButtons) {
                start = Math.max(1, end - maxButtons + 1);
              }
              const pages: number[] = [];
              for (let p = start; p <= end; p++) pages.push(p);
              return pages.map((pageNum) => {
                const isActive = safeCurrentPage === pageNum;
                return (
                  <button
                    key={pageNum}
                    type="button"
                    onClick={() => setCurrentPage(pageNum)}
                    className={`min-w-[32px] sm:min-w-[36px] h-8 sm:h-9 flex items-center justify-center rounded-xl text-xs sm:text-sm font-bold transition-all cursor-pointer ${
                      isActive
                        ? 'bg-[#0f2744] text-white shadow-2xs'
                        : 'border border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    {pageNum}
                  </button>
                );
              });
            })()}

            {/* Next Page Button (>) */}
            <button
              type="button"
              disabled={safeCurrentPage >= totalPages}
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              className="p-1.5 sm:p-2 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 disabled:opacity-40 disabled:pointer-events-none transition-colors cursor-pointer"
              title="الصفحة التالية"
              aria-label="التالي"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* MODALS */}
      <ConfirmDeleteModal
        isOpen={!!deleteTarget}
        title="حذف عميل نهائياً"
        itemName={deleteTarget?.name}
        description={(() => {
          if (!deleteTarget) return '';
          const imp = storage.getCustomerDeletionImpact(deleteTarget.id);
          if (!imp.invoices && !imp.returns && !imp.payments) {
            return 'لا توجد فواتير أو دفعات على هذا العميل، سيتم حذفه مع كشف حسابه.';
          }
          return `سيتم حذف ${imp.invoices} فاتورة و${imp.payments} دفعة و${imp.returns} مرتجع لهذا العميل، مع إرجاع الكميات للمخزون وعكس المبالغ المقبوضة من الخزينة. لا يمكن التراجع.`;
        })()}
        onClose={() => setDeleteTarget(null)}
        onConfirm={async () => {
          if (deleteTarget) {
            const res = await storage.deleteCustomer(deleteTarget.id);
            if (res.success) {
              setDeleteTarget(null);
            }
            return res;
          }
          return { success: false, error: 'لم يتم تحديد العميل' };
        }}
      />

      <CustomerModal
        isOpen={customerModalOpen}
        onClose={() => setCustomerModalOpen(false)}
        customerToEdit={editingCustomer}
        onSaved={loadCustomers}
      />

      {selectedLedgerCustomer && (
        <CustomerLedgerModal
          customer={selectedLedgerCustomer}
          onClose={() => setSelectedLedgerCustomer(null)}
          onReceivePaymentClick={(cust) => setSelectedPaymentCustomer(cust)}
        />
      )}

      <CustomerPaymentModal
        customer={selectedPaymentCustomer}
        onClose={() => setSelectedPaymentCustomer(null)}
        onSuccess={loadCustomers}
      />
    </div>
  );
};
