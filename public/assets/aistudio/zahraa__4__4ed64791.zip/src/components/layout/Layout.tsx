import React, { useState, useEffect } from 'react';
import { Header } from './Header';
import { BottomNavigationBar } from './BottomNavigationBar';
import { HomeSections } from '../home/HomeSections';
import { UserAccount } from '../../lib/auth';
import { SettingsAndProfileModal } from './SettingsAndProfileModal';
import { ThemeCustomizerModal } from './ThemeCustomizerModal';
import { getThemeConfig, subscribeTheme, ThemeConfig } from '../../lib/themeManager';
import { SimsimModal } from '../ai/SimsimModal';
import { ProductModal } from '../products/ProductModal';
import { ExpenseModal } from '../treasury/ExpenseModal';
import { CustomerModal } from '../customers/CustomerModal';
import { storage } from '../../lib/storage';

interface LayoutProps {
  children: React.ReactNode;
  activeTab: string;
  onSelectTab: (tab: string) => void;
  currentUser: UserAccount;
  onLogout: () => void;
  onUserUpdated?: (user: UserAccount) => void;
}

export const Layout: React.FC<LayoutProps> = ({
  children,
  activeTab,
  onSelectTab,
  currentUser,
  onLogout,
  onUserUpdated,
}) => {
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [themeModalOpen, setThemeModalOpen] = useState(false);
  const [simsimOpen, setSimsimOpen] = useState(false);

  // Quick Action Modals triggered by Simsim
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [expenseModalOpen, setExpenseModalOpen] = useState(false);
  const [customerModalOpen, setCustomerModalOpen] = useState(false);

  const [themeConfig, setThemeConfig] = useState<ThemeConfig>(() => getThemeConfig());

  useEffect(() => {
    return subscribeTheme((newCfg) => {
      setThemeConfig({ ...newCfg });
    });
  }, []);

  return (
    <div
      key={`${themeConfig.palette}-${themeConfig.mode}-${themeConfig.font}`}
      className="min-h-screen flex flex-col font-sans w-full overflow-x-hidden transition-colors duration-200"
      style={{
        backgroundColor: 'var(--theme-page-bg, #f8fafc)',
        color: 'var(--theme-text-color, #0f172a)',
      }}
    >
      {/* 1. Header with Brand Logo, Simsim AI Button, and Settings Gear */}
      <Header
        onGoHome={() => onSelectTab('dashboard')}
        currentUser={currentUser}
        onOpenSettingsModal={() => setSettingsModalOpen(true)}
        onOpenThemeModal={() => setThemeModalOpen(true)}
        onLogout={onLogout}
        onNavigateToTab={onSelectTab}
        onOpenSimsim={() => setSimsimOpen(true)}
      />

      {/* 2. Main Responsive Content Area with generous bottom spacing so navbar never obscures content */}
      <main className="flex-1 p-2.5 sm:p-5 md:p-6 lg:p-8 focus:outline-none w-full pb-44 sm:pb-52 md:pb-60">
        <div className="max-w-[1920px] mx-auto w-full">
          {/* Dashboard view: Home Sections (Hero, slider, about, team) only */}
          {activeTab === 'dashboard' && (
            <HomeSections
              onNavigate={onSelectTab}
              onOpenSimsim={() => setSimsimOpen(true)}
            />
          )}

          {/* Page Body Content */}
          <div className="w-full">
            {children}
          </div>

          {/* Generous bottom spacing buffer ensuring complete visibility above the bottom navigation bar */}
          <div className="h-28 sm:h-36 w-full pointer-events-none" aria-hidden="true" />
        </div>
      </main>

      {/* 3. Bottom Navigation Bar for System Departments */}
      <BottomNavigationBar
        activeTab={activeTab}
        onSelectTab={onSelectTab}
        currentUser={currentUser}
        onLogout={onLogout}
        onOpenSimsim={() => setSimsimOpen(true)}
        onOpenSettingsModal={() => setSettingsModalOpen(true)}
      />

      {/* 3. Global Settings & Profile Modal (Triggered by the Header Gear Icon) */}
      <SettingsAndProfileModal
        isOpen={settingsModalOpen}
        onClose={() => setSettingsModalOpen(false)}
        currentUser={currentUser}
        onOpenThemeModal={() => setThemeModalOpen(true)}
        onNavigateToTab={(tab) => {
          onSelectTab(tab);
          setSettingsModalOpen(false);
        }}
        onUserUpdated={onUserUpdated}
      />

      {/* 4. Global Theme & Fonts Customizer Modal */}
      <ThemeCustomizerModal
        isOpen={themeModalOpen}
        onClose={() => setThemeModalOpen(false)}
      />

      {/* 5. Simsim AI Interactive Assistant Modal */}
      <SimsimModal
        isOpen={simsimOpen}
        onClose={() => setSimsimOpen(false)}
        onNavigate={(tab) => {
          onSelectTab(tab);
        }}
        onOpenProductModal={() => setProductModalOpen(true)}
        onOpenExpenseModal={() => setExpenseModalOpen(true)}
        onOpenCustomerModal={() => setCustomerModalOpen(true)}
      />

      {/* 6. Quick Action Modals triggered by Simsim */}
      <ProductModal
        isOpen={productModalOpen}
        onClose={() => setProductModalOpen(false)}
        onSaved={() => storage.hydrate()}
      />

      <ExpenseModal
        isOpen={expenseModalOpen}
        onClose={() => setExpenseModalOpen(false)}
        onSuccess={() => storage.hydrate()}
      />

      <CustomerModal
        isOpen={customerModalOpen}
        onClose={() => setCustomerModalOpen(false)}
        onSaved={() => storage.hydrate()}
      />
    </div>
  );
};
