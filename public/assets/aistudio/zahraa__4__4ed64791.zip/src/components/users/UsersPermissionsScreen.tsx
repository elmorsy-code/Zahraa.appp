import React, { useState, useEffect, useMemo } from 'react';
import {
  ShieldCheck,
  UserCheck,
  Key,
  Shield,
  UserPlus,
  CheckCircle2,
  XCircle,
  Edit3,
  Lock,
  Loader2,
  AlertCircle,
  Mail,
  Phone,
  User,
  Sliders,
  Check,
  Settings as SettingsIcon,
  LayoutDashboard,
  Users as UsersIcon,
  Coins,
  FileSpreadsheet,
  Pill,
  Receipt,
  Truck,
  Landmark,
  BookOpenCheck,
  BarChart3,
  Search,
  Filter,
  LayoutList,
  LayoutGrid,
  CheckCircle,
  Eye,
  EyeOff,
  AlertTriangle,
  ArrowRight,
  UserX,
  X,
  ChevronDown,
  Building2,
  Layers,
  Sparkles,
  DollarSign,
  Printer,
  Trash2,
  PlusCircle,
  RefreshCw,
} from 'lucide-react';
import { RoleType, UserPermissions } from '../../types/database';
import {
  authService,
  UserAccount,
  SUPERVISOR_PRESETS,
  SupervisorRolePreset,
  DEFAULT_SUPERVISOR_PERMISSIONS,
} from '../../lib/auth';

// 11 Core System Sections grouped by business domain
interface SystemSection {
  id: string;
  name: string;
  desc: string;
  group: 'operations' | 'inventory' | 'finance';
  icon: React.ComponentType<{ className?: string }>;
}

const AVAILABLE_SECTIONS: SystemSection[] = [
  // Operations & Customers
  {
    id: 'dashboard',
    name: 'الرئيسية والمؤشرات الحية',
    desc: 'لوحة التحكم والملخص المالي اليومي',
    group: 'operations',
    icon: LayoutDashboard,
  },
  {
    id: 'customers',
    name: 'سجل العملاء والمزارعين',
    desc: 'دليل العملاء، القرى، والأرصدة المستحقة',
    group: 'operations',
    icon: UsersIcon,
  },
  {
    id: 'debts',
    name: 'سجل الديون والمديونيات',
    desc: 'متابعة أعمار الديون وجداول السداد والتحصيل',
    group: 'operations',
    icon: Coins,
  },
  {
    id: 'customer_ledgers',
    name: 'كشوف الحسابات التفصيلية',
    desc: 'سجل حركات الفواتير والسدادات لكل عميل',
    group: 'operations',
    icon: FileSpreadsheet,
  },

  // Inventory & Purchasing
  {
    id: 'products',
    name: 'الأدوية والأصناف والمخزون',
    desc: 'دليل الأدوية والمبيدات والأرصدة الحالية',
    group: 'inventory',
    icon: Pill,
  },
  {
    id: 'invoices',
    name: 'فواتير المشتريات والواردات',
    desc: 'تسجيل فواتير الشراء من الشركات والموردين',
    group: 'inventory',
    icon: Receipt,
  },
  {
    id: 'suppliers',
    name: 'حسابات الموردين والشركات',
    desc: 'دليل الموردين، الأرصدة، وسندات الشراء',
    group: 'inventory',
    icon: Truck,
  },

  // Finance & Management
  {
    id: 'treasury',
    name: 'الخزينة والمصروفات',
    desc: 'حركة السيولة النقدية وسندات القبض والصرف',
    group: 'finance',
    icon: Landmark,
  },
  {
    id: 'old_ledgers',
    name: 'ترحيل الدفاتر الورقية القديمة',
    desc: 'سجلات ترحيل الأرصدة والدفاتر السابقة',
    group: 'finance',
    icon: BookOpenCheck,
  },
  {
    id: 'reports',
    name: 'التقارير المالية والأرباح',
    desc: 'تحليلات المبيعات، التدفقات النقدية، والأرباح',
    group: 'finance',
    icon: BarChart3,
  },
  {
    id: 'settings',
    name: 'إعدادات المنظومة والسحابة',
    desc: 'بيانات المنشأة، النسخ الاحتياطي، وإعدادات النظام',
    group: 'finance',
    icon: SettingsIcon,
  },
];

const SECTION_GROUPS: Record<
  SystemSection['group'],
  { label: string; description: string; icon: React.ComponentType<{ className?: string }> }
> = {
  operations: {
    label: 'العمليات وسجل العملاء',
    description: 'شاشات خدمة المزارعين، الديون، وكشوف الحسابات',
    icon: UsersIcon,
  },
  inventory: {
    label: 'المخزون والمشتريات',
    description: 'الأدوية الزراعية، فواتير الشراء، والشركات الموردة',
    icon: Pill,
  },
  finance: {
    label: 'المالية وإدارة النظام',
    description: 'الخزينة العامة، المصروفات، التقارير والأرباح',
    icon: Landmark,
  },
};

// Operational Action Privileges categorized logically
interface ActionPrivilege {
  id: keyof Omit<UserPermissions, 'allowedTabs'>;
  label: string;
  description: string;
  category: 'core' | 'finance' | 'visibility' | 'security';
  isDangerous?: boolean;
}

const ACTION_PRIVILEGES: ActionPrivilege[] = [
  {
    id: 'canAdd',
    label: 'إضافة سجلات جديدة',
    description: 'إنشاء عملاء، فواتير مشتريات، أصناف، وموردين جدد',
    category: 'core',
  },
  {
    id: 'canEdit',
    label: 'تعديل وتحديث البيانات',
    description: 'تعديل أسعار البيع، بيانات العملاء، وتحديث السجلات',
    category: 'core',
  },
  {
    id: 'canCollect',
    label: 'تحصيل دفعات وسندات قبض',
    description: 'تسجيل سداد مديونيات العملاء وإيداعها في الصندوق',
    category: 'finance',
  },
  {
    id: 'canDisburse',
    label: 'صرف نقدية ومصروفات تشغيلية',
    description: 'إخراج مبالغ نقدية للمصروفات وسداد دفعات الموردين',
    category: 'finance',
  },
  {
    id: 'canViewCostPrices',
    label: 'عرض أسعار التكلفة والشراء',
    description: 'إظهار سعر الشراء وتكلفة البضاعة في جداول الأصناف',
    category: 'visibility',
  },
  {
    id: 'canViewProfits',
    label: 'عرض الأرباح والتقارير المالية',
    description: 'إظهار هوامش الربح وصافي الأرباح في اللوحة والتقارير',
    category: 'visibility',
  },
  {
    id: 'canExportPrint',
    label: 'طباعة وتصدير الكشوفات',
    description: 'طباعة الفواتير وكشوف الحسابات وتصدير ملفات البيانات',
    category: 'visibility',
  },
  {
    id: 'canDelete',
    label: 'حذف السجلات والبيانات',
    description: 'إمكانية حذف الفواتير أو العملاء أو الأصناف نهائياً',
    category: 'security',
    isDangerous: true,
  },
];

export const UsersPermissionsScreen: React.FC = () => {
  const [users, setUsers] = useState<UserAccount[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('table');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterRole, setFilterRole] = useState<'all' | 'supervisor' | 'admin' | 'active' | 'inactive'>('all');

  // Modals state
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [selectedUserForPassword, setSelectedUserForPassword] = useState<UserAccount | null>(null);
  const [showPasswordText, setShowPasswordText] = useState(false);

  // Edit Role & Permissions Modal
  const [showPermsModal, setShowPermsModal] = useState(false);
  const [editingSupervisor, setEditingSupervisor] = useState<UserAccount | null>(null);
  const [selectedPresetId, setSelectedPresetId] = useState<string>('sales_supervisor');
  const [customRoleTitle, setCustomRoleTitle] = useState('');
  const [editFullName, setEditFullName] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [customPermissions, setCustomPermissions] = useState<UserPermissions>(DEFAULT_SUPERVISOR_PERMISSIONS);
  const [permsModalLoading, setPermsModalLoading] = useState(false);
  const [permsModalError, setPermsModalError] = useState('');

  // Add User Form States
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<RoleType>('supervisor');
  const [addPresetId, setAddPresetId] = useState<string>('sales_supervisor');
  const [addRoleTitle, setAddRoleTitle] = useState('مشرف مبيعات وعملاء');
  const [addPermissions, setAddPermissions] = useState<UserPermissions>(() => {
    return SUPERVISOR_PRESETS.find((p) => p.id === 'sales_supervisor')?.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;
  });
  const [modalLoading, setModalLoading] = useState(false);
  const [formError, setFormError] = useState('');
  const [successToast, setSuccessToast] = useState('');

  // Password reset modal states
  const [newPassword, setNewPassword] = useState('');
  const [passwordModalLoading, setPasswordModalLoading] = useState(false);
  const [passwordModalError, setPasswordModalError] = useState('');

  // Quick Sections Popover / preview state for table
  const [activePreviewUserId, setActivePreviewUserId] = useState<string | null>(null);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    setLoading(true);
    try {
      const data = await authService.getProfiles();
      setUsers(data);
    } catch (err) {
      console.error('Failed to load users:', err);
    } finally {
      setLoading(false);
    }
  };

  // Filtered Users List
  const filteredUsers = useMemo(() => {
    return users.filter((u) => {
      // Role & status filter
      if (filterRole === 'admin' && u.role !== 'admin') return false;
      if (filterRole === 'supervisor' && u.role === 'admin') return false;
      if (filterRole === 'active' && !u.isActive) return false;
      if (filterRole === 'inactive' && u.isActive) return false;

      // Search query
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        u.fullName.toLowerCase().includes(q) ||
        (u.email && u.email.toLowerCase().includes(q)) ||
        (u.phone && u.phone.includes(q)) ||
        (u.roleNameAr && u.roleNameAr.toLowerCase().includes(q)) ||
        (u.supervisorRoleTitle && u.supervisorRoleTitle.toLowerCase().includes(q))
      );
    });
  }, [users, filterRole, searchQuery]);

  // Statistics
  const stats = useMemo(() => {
    const total = users.length;
    const active = users.filter((u) => u.isActive).length;
    const supervisors = users.filter((u) => u.role !== 'admin').length;
    const financialPrivileges = users.filter((u) => {
      if (u.role === 'admin') return true;
      return u.permissions?.canCollect || u.permissions?.canDisburse;
    }).length;
    return { total, active, supervisors, financialPrivileges };
  }, [users]);

  // Open Edit Permissions Modal
  const handleOpenPermsModal = (user: UserAccount) => {
    setEditingSupervisor(user);
    setPermsModalError('');
    setEditFullName(user.fullName || '');
    setEditPhone(user.phone || '');

    const currentTitle = user.supervisorRoleTitle || user.roleNameAr || 'مشرف';
    const matchedPreset = SUPERVISOR_PRESETS.find(
      (p) => p.name === currentTitle || (p.id === 'general_supervisor' && currentTitle.includes('عام'))
    );

    if (matchedPreset) {
      setSelectedPresetId(matchedPreset.id);
      setCustomRoleTitle(matchedPreset.name);
    } else {
      setSelectedPresetId('custom_supervisor');
      setCustomRoleTitle(currentTitle);
    }

    setCustomPermissions({
      allowedTabs: user.permissions?.allowedTabs || DEFAULT_SUPERVISOR_PERMISSIONS.allowedTabs,
      canAdd: user.permissions?.canAdd ?? false,
      canEdit: user.permissions?.canEdit ?? false,
      canDelete: user.permissions?.canDelete ?? false,
      canCollect: user.permissions?.canCollect ?? false,
      canDisburse: user.permissions?.canDisburse ?? false,
      canViewCostPrices: user.permissions?.canViewCostPrices ?? false,
      canViewProfits: user.permissions?.canViewProfits ?? false,
      canExportPrint: user.permissions?.canExportPrint ?? true,
    });

    setShowPermsModal(true);
  };

  const handleSelectPreset = (preset: SupervisorRolePreset) => {
    setSelectedPresetId(preset.id);
    setCustomRoleTitle(preset.name);
    setCustomPermissions({ ...preset.permissions });
  };

  const handleToggleTab = (tabId: string) => {
    setCustomPermissions((prev) => {
      const exists = prev.allowedTabs.includes(tabId);
      const newTabs = exists
        ? prev.allowedTabs.filter((t) => t !== tabId)
        : [...prev.allowedTabs, tabId];
      return { ...prev, allowedTabs: newTabs };
    });
  };

  const handleSelectAllTabs = () => {
    setCustomPermissions((prev) => ({
      ...prev,
      allowedTabs: AVAILABLE_SECTIONS.map((s) => s.id),
    }));
  };

  const handleClearAllTabs = () => {
    setCustomPermissions((prev) => ({
      ...prev,
      allowedTabs: ['dashboard'],
    }));
  };

  const handleTogglePrivilege = (key: keyof Omit<UserPermissions, 'allowedTabs'>) => {
    setCustomPermissions((prev) => ({
      ...prev,
      [key]: !prev[key],
    }));
  };

  const handleSaveSupervisorPerms = async () => {
    if (!editingSupervisor) return;
    if (!editFullName.trim()) {
      setPermsModalError('يرجى إدخال اسم المشرف');
      return;
    }
    if (!customRoleTitle.trim()) {
      setPermsModalError('يرجى كتابة المسمى الوظيفي المعتمد للمشرف');
      return;
    }

    setPermsModalLoading(true);
    setPermsModalError('');
    try {
      const res = await authService.adminUpdateSupervisorRoleAndPermissions(
        editingSupervisor.id,
        customRoleTitle.trim(),
        customPermissions,
        undefined,
        { fullName: editFullName.trim(), phone: editPhone.trim() }
      );

      if (!res.success) {
        setPermsModalError(res.error || 'فشل حفظ التعديلات');
        setPermsModalLoading(false);
        return;
      }

      setSuccessToast(`تم تحديث دور وصلاحيات المشرف "${editingSupervisor.fullName}" بنجاح`);
      setTimeout(() => setSuccessToast(''), 4000);
      setShowPermsModal(false);
      await loadUsers();
    } catch (err: any) {
      setPermsModalError(err?.message || 'حدث خطأ أثناء حفظ الصلاحيات');
    } finally {
      setPermsModalLoading(false);
    }
  };

  // Open Add User
  const handleOpenAdd = () => {
    setFullName('');
    setEmail('');
    setPassword('');
    setPhone('');
    setRole('supervisor');
    setAddPresetId('sales_supervisor');
    const defaultPreset = SUPERVISOR_PRESETS.find((p) => p.id === 'sales_supervisor')!;
    setAddRoleTitle(defaultPreset.name);
    setAddPermissions({ ...defaultPreset.permissions });
    setFormError('');
    setShowAddModal(true);
  };

  const handleAddPresetChange = (presetId: string) => {
    setAddPresetId(presetId);
    const p = SUPERVISOR_PRESETS.find((item) => item.id === presetId);
    if (p) {
      setAddRoleTitle(p.name);
      setAddPermissions({ ...p.permissions });
    }
  };

  const handleSaveUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!fullName.trim()) {
      setFormError('يرجى إدخال الاسم الكامل للمشرف');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      setFormError('يرجى إدخال بريد إلكتروني صحيح');
      return;
    }
    if (password.length < 6) {
      setFormError('كلمة المرور يجب أن لا تقل عن 6 خانات');
      return;
    }

    setModalLoading(true);
    try {
      const res = await authService.adminCreateUser({
        email: email.trim(),
        password,
        fullName: fullName.trim(),
        phone: phone.trim(),
        role: role,
        supervisorRoleTitle: addRoleTitle.trim(),
        permissions: addPermissions,
        description: addRoleTitle.trim(),
      });

      if (!res.success) {
        setFormError(res.error || 'فشل إنشاء الحساب في قاعدة البيانات');
        setModalLoading(false);
        return;
      }

      setSuccessToast(`تم إنشاء حساب المشرف "${fullName}" واعتماد صلاحياته بنجاح`);
      setTimeout(() => setSuccessToast(''), 4000);
      setShowAddModal(false);
      await loadUsers();
    } catch (err: any) {
      setFormError(err?.message || 'حدث خطأ أثناء حفظ الحساب');
    } finally {
      setModalLoading(false);
    }
  };

  const handleToggleStatus = async (user: UserAccount) => {
    if (user.role === 'admin') return;
    const success = await authService.adminToggleUserStatus(user.id, user.isActive);
    if (success) {
      setSuccessToast(
        user.isActive ? `تم إيقاف حساب ${user.fullName} مؤقتاً` : `تم تفعيل حساب ${user.fullName} بنجاح`
      );
      setTimeout(() => setSuccessToast(''), 3000);
      await loadUsers();
    }
  };

  const handleOpenPasswordModal = (user: UserAccount) => {
    setSelectedUserForPassword(user);
    setNewPassword('');
    setShowPasswordText(false);
    setPasswordModalError('');
    setShowPasswordModal(true);
  };

  const handleSavePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUserForPassword) return;
    if (newPassword.length < 6) {
      setPasswordModalError('كلمة المرور يجب ألا تقل عن 6 خانات');
      return;
    }

    setPasswordModalLoading(true);
    setPasswordModalError('');
    try {
      const res = await authService.adminUpdateUserPassword(selectedUserForPassword.id, newPassword);

      if (!res.success) {
        setPasswordModalError(res.error || 'فشل تحديث كلمة المرور');
        setPasswordModalLoading(false);
        return;
      }

      setSuccessToast(`تم تعيين كلمة مرور جديدة للمستخدم "${selectedUserForPassword.fullName}" بنجاح`);
      setTimeout(() => setSuccessToast(''), 4000);
      setShowPasswordModal(false);
    } catch (err: any) {
      setPasswordModalError(err?.message || 'حدث خطأ أثناء التحديث');
    } finally {
      setPasswordModalLoading(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Toast Notification */}
      {successToast && (
        <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 py-3 px-5 bg-slate-900 text-white font-bold rounded-2xl shadow-xl flex items-center gap-2.5 animate-in fade-in slide-in-from-top-4 border border-slate-700">
          <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="text-xs sm:text-sm">{successToast}</span>
        </div>
      )}

      {/* 1. Executive Master Header */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-7 shadow-xs">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500">
              <span>النظام الإداري المتقدم</span>
              <span aria-hidden="true">/</span>
              <span className="text-emerald-700 font-bold">صلاحيات وأدوار المشرفين</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center shrink-0 shadow-xs">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
              </div>
              <span>إدارة الحسابات وصلاحيات المشرفين</span>
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 font-medium max-w-2xl leading-relaxed">
              مركز تحكم المدير العام: تخصيص مسمى ودور كل مشرف، وتحديد الأقسام المصرح بها، والتحكم الدقيق في صلاحيات الإضافة والتعديل والتحصيل والطباعة.
            </p>
          </div>

          <div className="flex items-center gap-2.5 shrink-0 self-start lg:self-center">
            <button
              onClick={loadUsers}
              type="button"
              className="p-2.5 rounded-xl border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 cursor-pointer transition-colors"
              title="تحديث البيانات"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
            </button>
            <button
              onClick={handleOpenAdd}
              type="button"
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs sm:text-sm shadow-xs cursor-pointer transition-all active:scale-[0.98]"
            >
              <UserPlus className="w-4 h-4 text-emerald-400" />
              <span>إضافة حساب مشرف جديد</span>
            </button>
          </div>
        </div>

        {/* Quiet KPI Metrics Strip */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mt-6 pt-6 border-t border-slate-100">
          <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/60">
            <span className="text-[11px] font-semibold text-slate-500 block mb-1">إجمالي الحسابات المسجلة</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-900 font-mono tabular-nums">{stats.total}</span>
              <span className="text-[11px] text-slate-400 font-medium">حساب مسجل</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/60">
            <span className="text-[11px] font-semibold text-slate-500 block mb-1">المشرفون التشغيليون</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-blue-900 font-mono tabular-nums">{stats.supervisors}</span>
              <span className="text-[11px] text-slate-400 font-medium">مشرف معتمد</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/60">
            <span className="text-[11px] font-semibold text-slate-500 block mb-1">الحسابات النشطة حالياً</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-emerald-700 font-mono tabular-nums">{stats.active}</span>
              <span className="text-[11px] text-emerald-600 font-medium">نفاذ نشط</span>
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50/80 border border-slate-200/60">
            <span className="text-[11px] font-semibold text-slate-500 block mb-1">صلاحيات العمليات المالية</span>
            <div className="flex items-baseline gap-2">
              <span className="text-2xl font-black text-slate-800 font-mono tabular-nums">{stats.financialPrivileges}</span>
              <span className="text-[11px] text-slate-400 font-medium">تحصيل / صرف</span>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Search, Filter & View Controls Bar */}
      <div className="bg-white rounded-2xl border border-slate-200/90 p-3 sm:p-4 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث بالاسم، البريد الإلكتروني، أو المسمى الوظيفي..."
            className="w-full pr-10 pl-8 py-2 bg-slate-50 hover:bg-slate-100/70 focus:bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-medium text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10 transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute left-2.5 top-2.5 text-slate-400 hover:text-slate-600"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Tabs & View Toggle */}
        <div className="flex flex-wrap items-center justify-between sm:justify-end gap-2.5 shrink-0">
          {/* Segmented Filter Control */}
          <div className="flex items-center gap-1 p-1 bg-slate-100/80 rounded-xl border border-slate-200/60 text-xs font-bold">
            <button
              type="button"
              onClick={() => setFilterRole('all')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                filterRole === 'all'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              الكل ({users.length})
            </button>
            <button
              type="button"
              onClick={() => setFilterRole('supervisor')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                filterRole === 'supervisor'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              المشرفين ({stats.supervisors})
            </button>
            <button
              type="button"
              onClick={() => setFilterRole('admin')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                filterRole === 'admin'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              المدير العام
            </button>
            <button
              type="button"
              onClick={() => setFilterRole('active')}
              className={`px-3 py-1.5 rounded-lg transition-colors cursor-pointer ${
                filterRole === 'active'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              النشطة ({stats.active})
            </button>
          </div>

          {/* View Mode Toggle */}
          <div className="flex items-center gap-1 p-1 bg-slate-100/80 rounded-xl border border-slate-200/60">
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'table' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
              title="عرض كجدول منظم"
            >
              <LayoutList className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                viewMode === 'grid' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500 hover:text-slate-800'
              }`}
              title="عرض كبطاقات تفصيلية"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* 3. Main Accounts Directory */}
      {loading ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-16 text-center flex flex-col items-center justify-center gap-3">
          <Loader2 className="w-8 h-8 text-slate-700 animate-spin" />
          <span className="text-sm font-bold text-slate-600">جارٍ جلب حسابات المستخدمين وصلاحيات المشرفين...</span>
        </div>
      ) : filteredUsers.length === 0 ? (
        <div className="bg-white rounded-2xl border border-slate-200 p-16 text-center space-y-3">
          <UserX className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-base font-bold text-slate-800">لا توجد حسابات تطابق معايير البحث</h3>
          <p className="text-xs text-slate-500">جرب تغيير كلمة البحث أو إعادة تعيين الفلاتر.</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setFilterRole('all');
            }}
            type="button"
            className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer pt-2 inline-block"
          >
            إعادة تعيين الفلاتر
          </button>
        </div>
      ) : viewMode === 'table' ? (
        /* =========================================================================
           TABLE VIEW: Executive, Clean, Readable
           ========================================================================= */
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="bg-slate-50/90 border-b border-slate-200 text-slate-500 font-bold">
                  <th className="py-3.5 px-5 font-bold text-slate-700">المستخدم والبريد</th>
                  <th className="py-3.5 px-4 font-bold text-slate-700">المسمى والدور المعتمد</th>
                  <th className="py-3.5 px-4 font-bold text-slate-700">نطاق الشاشات المصرح بها</th>
                  <th className="py-3.5 px-4 font-bold text-slate-700">صلاحيات العمليات والرقابة</th>
                  <th className="py-3.5 px-4 font-bold text-slate-700">حالة الحساب</th>
                  <th className="py-3.5 px-5 text-center font-bold text-slate-700">إجراءات المدير العام</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredUsers.map((user) => {
                  const isAdminUser = user.role === 'admin';
                  const userPerms = user.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;
                  const allowedTabsList = isAdminUser
                    ? AVAILABLE_SECTIONS.map((s) => s.id)
                    : (userPerms.allowedTabs || []);
                  const allowedCount = allowedTabsList.length;
                  const isPreviewOpen = activePreviewUserId === user.id;

                  // Distinct badge color for roles
                  const roleBadgeStyle = isAdminUser
                    ? 'bg-slate-900 text-white'
                    : user.supervisorRoleTitle?.includes('مبيعات')
                    ? 'bg-blue-50 text-blue-800 border border-blue-200'
                    : user.supervisorRoleTitle?.includes('مخازن')
                    ? 'bg-teal-50 text-teal-800 border border-teal-200'
                    : user.supervisorRoleTitle?.includes('خزينة')
                    ? 'bg-amber-50 text-amber-800 border border-amber-200'
                    : 'bg-emerald-50 text-emerald-800 border border-emerald-200';

                  return (
                    <tr key={user.id} className="hover:bg-slate-50/60 transition-colors">
                      {/* 1. User Identity */}
                      <td className="py-4 px-5">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center text-white font-black text-sm shrink-0 shadow-2xs ${
                              user.avatarColor || (isAdminUser ? 'bg-slate-900' : 'bg-slate-700')
                            }`}
                          >
                            {user.fullName.slice(0, 1)}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 text-sm block leading-snug">
                              {user.fullName}
                            </span>
                            <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono mt-0.5" dir="ltr">
                              <span>{user.email || user.username}</span>
                              {user.phone && (
                                <>
                                  <span aria-hidden="true" className="text-slate-300">·</span>
                                  <span>{user.phone}</span>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* 2. Role Title & Badge */}
                      <td className="py-4 px-4">
                        <div className="space-y-1">
                          <span
                            className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${roleBadgeStyle}`}
                          >
                            {isAdminUser && <Shield className="w-3.5 h-3.5 text-emerald-400" />}
                            <span>{user.supervisorRoleTitle || user.roleNameAr || (isAdminUser ? 'المدير العام' : 'مشرف')}</span>
                          </span>
                          {!isAdminUser && user.description && (
                            <span className="block text-[11px] text-slate-400 font-medium truncate max-w-xs">
                              {user.description}
                            </span>
                          )}
                        </div>
                      </td>

                      {/* 3. Allowed Sections Counter + Preview Popover */}
                      <td className="py-4 px-4">
                        <div className="relative">
                          <button
                            type="button"
                            onClick={() => setActivePreviewUserId(isPreviewOpen ? null : user.id)}
                            className="inline-flex items-center gap-2 px-2.5 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200/80 font-medium text-slate-700 cursor-pointer transition-colors"
                          >
                            <span className="font-mono font-bold text-slate-900 tabular-nums">{allowedCount}</span>
                            <span className="text-slate-500">من 11 قسم</span>
                            <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                          </button>

                          {/* Popover list of allowed modules */}
                          {isPreviewOpen && (
                            <div className="absolute top-full right-0 mt-1 z-30 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-3 animate-in fade-in zoom-in-95">
                              <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-[11px] font-bold text-slate-700">
                                <span>الأقسام المتاحة لـ {user.fullName}</span>
                                <button
                                  onClick={() => setActivePreviewUserId(null)}
                                  className="text-slate-400 hover:text-slate-600"
                                >
                                  <X className="w-3.5 h-3.5" />
                                </button>
                              </div>
                              <div className="mt-2 max-h-48 overflow-y-auto space-y-1.5">
                                {AVAILABLE_SECTIONS.map((sec) => {
                                  const isAllowed = allowedTabsList.includes(sec.id);
                                  const SecIcon = sec.icon;
                                  return (
                                    <div
                                      key={sec.id}
                                      className={`flex items-center gap-2 px-2 py-1 rounded text-[11px] ${
                                        isAllowed
                                          ? 'text-slate-900 bg-emerald-50/60 font-semibold'
                                          : 'text-slate-400 opacity-60 line-through'
                                      }`}
                                    >
                                      <SecIcon className="w-3.5 h-3.5 shrink-0" />
                                      <span className="truncate">{sec.name}</span>
                                      {isAllowed && (
                                        <Check className="w-3 h-3 text-emerald-600 mr-auto shrink-0" />
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* 4. Action Privileges Grid */}
                      <td className="py-4 px-4">
                        {isAdminUser ? (
                          <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-md">
                            كافة العمليات والرقابة مفتوحة
                          </span>
                        ) : (
                          <div className="flex flex-wrap items-center gap-1 text-[10px] font-bold">
                            <span
                              className={`px-1.5 py-0.5 rounded ${
                                userPerms.canAdd ? 'bg-slate-100 text-slate-900' : 'bg-slate-50 text-slate-400 line-through'
                              }`}
                            >
                              إضافة
                            </span>
                            <span
                              className={`px-1.5 py-0.5 rounded ${
                                userPerms.canEdit ? 'bg-slate-100 text-slate-900' : 'bg-slate-50 text-slate-400 line-through'
                              }`}
                            >
                              تعديل
                            </span>
                            <span
                              className={`px-1.5 py-0.5 rounded ${
                                userPerms.canCollect ? 'bg-blue-50 text-blue-900' : 'bg-slate-50 text-slate-400 line-through'
                              }`}
                            >
                              تحصيل
                            </span>
                            <span
                              className={`px-1.5 py-0.5 rounded ${
                                userPerms.canDisburse ? 'bg-amber-50 text-amber-900' : 'bg-slate-50 text-slate-400 line-through'
                              }`}
                            >
                              صرف
                            </span>
                            {userPerms.canDelete ? (
                              <span className="px-1.5 py-0.5 rounded bg-rose-100 text-rose-800 font-black">
                                حذف مسموح
                              </span>
                            ) : (
                              <span className="px-1.5 py-0.5 rounded bg-slate-50 text-slate-400">
                                بدون حذف
                              </span>
                            )}
                          </div>
                        )}
                      </td>

                      {/* 5. Status Toggle */}
                      <td className="py-4 px-4">
                        <button
                          type="button"
                          onClick={() => handleToggleStatus(user)}
                          disabled={isAdminUser}
                          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition-colors ${
                            user.isActive
                              ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                              : 'text-rose-700 bg-rose-50 hover:bg-rose-100'
                          } ${isAdminUser ? 'cursor-default opacity-80' : 'cursor-pointer'}`}
                          title={isAdminUser ? 'حساب المدير العام دائم النشاط' : 'انقر لتغيير حالة الحساب'}
                        >
                          <span
                            className={`w-2 h-2 rounded-full ${
                              user.isActive ? 'bg-emerald-600' : 'bg-rose-600'
                            }`}
                          />
                          <span>{user.isActive ? 'نشط' : 'معطل'}</span>
                        </button>
                      </td>

                      {/* 6. Executive Action Controls */}
                      <td className="py-4 px-5 text-center">
                        <div className="flex items-center justify-center gap-2">
                          {!isAdminUser ? (
                            <button
                              type="button"
                              onClick={() => handleOpenPermsModal(user)}
                              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer shadow-2xs transition-all active:scale-[0.98]"
                              title="تحديد دور المشرف وتعديل صلاحياته"
                            >
                              <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                              <span>تحديد الدور والصلاحيات</span>
                            </button>
                          ) : (
                            <span className="text-[11px] text-slate-400 font-semibold px-2 py-1 bg-slate-100 rounded-md">
                              حساب المدير العام
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={() => handleOpenPasswordModal(user)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-800 hover:bg-slate-100 cursor-pointer transition-colors"
                            title="تغيير كلمة المرور"
                          >
                            <Key className="w-4 h-4 text-slate-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* =========================================================================
           GRID VIEW: Modern Executive Cards
           ========================================================================= */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredUsers.map((user) => {
            const isAdminUser = user.role === 'admin';
            const userPerms = user.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;
            const allowedTabsCount = isAdminUser
              ? AVAILABLE_SECTIONS.length
              : (userPerms.allowedTabs?.length || 0);

            const roleBadgeStyle = isAdminUser
              ? 'bg-slate-900 text-white'
              : user.supervisorRoleTitle?.includes('مبيعات')
              ? 'bg-blue-50 text-blue-800 border border-blue-200'
              : user.supervisorRoleTitle?.includes('مخازن')
              ? 'bg-teal-50 text-teal-800 border border-teal-200'
              : user.supervisorRoleTitle?.includes('خزينة')
              ? 'bg-amber-50 text-amber-800 border border-amber-200'
              : 'bg-emerald-50 text-emerald-800 border border-emerald-200';

            return (
              <div
                key={user.id}
                className="bg-white rounded-2xl border border-slate-200/90 p-5 shadow-xs flex flex-col justify-between space-y-4 hover:border-slate-300 transition-all"
              >
                <div className="space-y-4">
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-11 h-11 rounded-xl flex items-center justify-center text-white font-black text-base shrink-0 shadow-2xs ${
                          user.avatarColor || (isAdminUser ? 'bg-slate-900' : 'bg-slate-700')
                        }`}
                      >
                        {user.fullName.slice(0, 1)}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm leading-snug">
                          {user.fullName}
                        </h4>
                        <span className="text-[11px] text-slate-500 font-mono block mt-0.5" dir="ltr">
                          {user.email || user.username}
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => handleToggleStatus(user)}
                      disabled={isAdminUser}
                      className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold ${
                        user.isActive
                          ? 'text-emerald-700 bg-emerald-50 hover:bg-emerald-100'
                          : 'text-rose-700 bg-rose-50 hover:bg-rose-100'
                      } ${isAdminUser ? 'cursor-default' : 'cursor-pointer'}`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full ${user.isActive ? 'bg-emerald-600' : 'bg-rose-600'}`} />
                      <span>{user.isActive ? 'نشط' : 'معطل'}</span>
                    </button>
                  </div>

                  {/* Role Title Badge */}
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    <span className="text-slate-500 font-medium">الدور الوظيفي:</span>
                    <span className={`font-bold px-2.5 py-1 rounded-lg ${roleBadgeStyle}`}>
                      {user.supervisorRoleTitle || user.roleNameAr || (isAdminUser ? 'المدير العام' : 'مشرف')}
                    </span>
                  </div>

                  {/* Summary Details */}
                  <div className="space-y-2 text-xs bg-slate-50/70 p-3 rounded-xl border border-slate-100">
                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">نطاق الشاشات:</span>
                      <span className="font-bold text-slate-900 font-mono tabular-nums">{allowedTabsCount} من 11 قسم</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">إضافة وتعديل:</span>
                      <span className="font-bold text-slate-800">
                        {isAdminUser || (userPerms.canAdd && userPerms.canEdit)
                          ? 'مفعلة'
                          : userPerms.canAdd
                          ? 'إضافة فقط'
                          : 'معطلة'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">التحصيل المالي:</span>
                      <span className="font-bold text-slate-800">
                        {isAdminUser || userPerms.canCollect ? 'مسموح' : 'محظور'}
                      </span>
                    </div>

                    <div className="flex items-center justify-between">
                      <span className="text-slate-500">حذف السجلات:</span>
                      <span className={`font-bold ${userPerms.canDelete ? 'text-rose-600' : 'text-slate-500'}`}>
                        {userPerms.canDelete ? 'مسموح (حذر)' : 'محظور أمنياً'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => handleOpenPasswordModal(user)}
                    className="p-2 rounded-xl text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer border border-slate-200"
                    title="تغيير كلمة المرور"
                  >
                    <Key className="w-4 h-4" />
                  </button>

                  {!isAdminUser ? (
                    <button
                      type="button"
                      onClick={() => handleOpenPermsModal(user)}
                      className="flex-1 inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs cursor-pointer transition-colors shadow-2xs"
                    >
                      <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                      <span>تحديد الدور والصلاحيات</span>
                    </button>
                  ) : (
                    <span className="text-xs font-bold text-slate-400 py-1.5">صلاحيات كاملة للمدير العام</span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* =========================================================================
          MODAL: Configure Supervisor Role & Permissions
         ========================================================================= */}
      {showPermsModal && editingSupervisor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-3xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-6 flex flex-col max-h-[92vh]">
            {/* Modal Header with User Profile Summary */}
            <div className="p-5 sm:p-6 bg-slate-900 text-white flex justify-between items-start shrink-0">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 font-bold text-[11px]">
                    التحكم بصلاحيات المشرف
                  </span>
                  <span className="text-xs text-slate-400">·</span>
                  <span className="text-xs text-slate-300 font-mono" dir="ltr">
                    {editingSupervisor.email}
                  </span>
                </div>
                <h3 className="font-black text-xl flex items-center gap-2.5">
                  <Sliders className="w-5 h-5 text-emerald-400" />
                  <span>تحديد دور المشرف: {editingSupervisor.fullName}</span>
                </h3>
                <p className="text-xs text-slate-400">
                  حدد القالب الوظيفي المعتمد أو خصص الشاشات والعمليات التشغيلية والمالية بدقة.
                </p>
              </div>
              <button
                onClick={() => setShowPermsModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {permsModalError && (
              <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs font-bold text-rose-800 shrink-0">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{permsModalError}</span>
              </div>
            )}

            {/* Modal Body */}
            <div className="p-5 sm:p-6 space-y-6 overflow-y-auto flex-1">
              {/* SECTION 1: Role Preset Templates */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-600" />
                    <span>الخطوة 1: اختيار نموذج الدور الوظيفي السريع</span>
                  </label>
                  <span className="text-[11px] text-slate-400">ينصح باختيار أحد النماذج المعتمدة</span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                  {SUPERVISOR_PRESETS.map((preset) => {
                    const isSelected = selectedPresetId === preset.id;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => handleSelectPreset(preset)}
                        className={`p-3 rounded-xl border text-right transition-all cursor-pointer relative flex flex-col justify-between ${
                          isSelected
                            ? 'border-slate-900 bg-slate-900 text-white shadow-xs'
                            : 'border-slate-200 bg-white hover:border-slate-300 text-slate-800'
                        }`}
                      >
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-xs">{preset.name}</span>
                            {isSelected && (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                            )}
                          </div>
                          <p
                            className={`text-[11px] line-clamp-2 leading-relaxed ${
                              isSelected ? 'text-slate-300' : 'text-slate-500'
                            }`}
                          >
                            {preset.description}
                          </p>
                        </div>
                        <div
                          className={`mt-2 pt-2 border-t text-[10px] font-semibold flex items-center justify-between ${
                            isSelected ? 'border-slate-800 text-slate-300' : 'border-slate-100 text-slate-400'
                          }`}
                        >
                          <span>{preset.permissions.allowedTabs.length} أقسام مصرحة</span>
                          <span>{preset.permissions.canCollect ? 'تحصيل متاح' : 'بدون تحصيل'}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Supervisor basic info */}
                <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">اسم المشرف:</label>
                    <input
                      type="text"
                      value={editFullName}
                      onChange={(e) => setEditFullName(e.target.value)}
                      placeholder="الاسم الكامل"
                      className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">رقم الهاتف:</label>
                    <input
                      type="tel"
                      dir="ltr"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                      placeholder="01xxxxxxxxx"
                      className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                    />
                  </div>
                </div>

                {/* Custom Role Title */}
                <div className="pt-2">
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">
                    المسمى الوظيفي المعتمد للمشرف (يظهر في الترويسة والفواتير والسجلات):
                  </label>
                  <input
                    type="text"
                    value={customRoleTitle}
                    onChange={(e) => {
                      setCustomRoleTitle(e.target.value);
                      setSelectedPresetId('custom_supervisor');
                    }}
                    placeholder="مثال: مشرف مبيعات وعملاء، مشرف مخازن ومشتريات..."
                    className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                  />
                </div>
              </div>

              {/* SECTION 2: Allowed System Sections */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div>
                    <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <Layers className="w-4 h-4 text-blue-600" />
                      <span>الخطوة 2: شاشات وأقسام المنظومة المصرح بها ({customPermissions.allowedTabs.length} من 11)</span>
                    </h4>
                    <span className="text-[11px] text-slate-500">
                      الشاشات غير المحددة ستختفي تماماً من شريط التنقل للمشرف ولا يمكنه فتحها.
                    </span>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
                    <button
                      type="button"
                      onClick={handleSelectAllTabs}
                      className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold cursor-pointer transition-colors"
                    >
                      تحديد كل الأقسام
                    </button>
                    <button
                      type="button"
                      onClick={handleClearAllTabs}
                      className="px-2.5 py-1 rounded-lg text-slate-500 hover:text-slate-800 text-xs font-bold cursor-pointer transition-colors"
                    >
                      الرئيسية فقط
                    </button>
                  </div>
                </div>

                {/* Grouped Sections */}
                {(['operations', 'inventory', 'finance'] as const).map((groupKey) => {
                  const groupInfo = SECTION_GROUPS[groupKey];
                  const groupSections = AVAILABLE_SECTIONS.filter((s) => s.group === groupKey);
                  const GroupIcon = groupInfo.icon;

                  return (
                    <div key={groupKey} className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-bold text-slate-700 bg-slate-50 px-3 py-1.5 rounded-lg border border-slate-100">
                        <GroupIcon className="w-3.5 h-3.5 text-slate-600" />
                        <span>{groupInfo.label}</span>
                        <span className="text-[11px] text-slate-400 font-normal">({groupInfo.description})</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {groupSections.map((sec) => {
                          const isChecked = customPermissions.allowedTabs.includes(sec.id);
                          const SecIcon = sec.icon;

                          return (
                            <div
                              key={sec.id}
                              onClick={() => handleToggleTab(sec.id)}
                              className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-all select-none ${
                                isChecked
                                  ? 'border-slate-900 bg-slate-50/80 shadow-2xs'
                                  : 'border-slate-200 bg-white hover:border-slate-300'
                              }`}
                            >
                              <div className="flex items-center gap-3">
                                <div
                                  className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                                    isChecked ? 'bg-slate-900 text-white' : 'bg-slate-100 text-slate-500'
                                  }`}
                                >
                                  <SecIcon className="w-4 h-4" />
                                </div>
                                <div>
                                  <span className="text-xs font-bold text-slate-900 block leading-tight">
                                    {sec.name}
                                  </span>
                                  <span className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{sec.desc}</span>
                                </div>
                              </div>

                              <div
                                className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${
                                  isChecked
                                    ? 'bg-slate-900 border-slate-900 text-white'
                                    : 'border-slate-300 bg-white'
                                }`}
                              >
                                {isChecked && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* SECTION 3: Operational Privileges & Security Toggles */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <div>
                  <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <Sliders className="w-4 h-4 text-emerald-600" />
                    <span>الخطوة 3: صلاحيات العمليات والرقابة التشغيلية</span>
                  </h4>
                  <span className="text-[11px] text-slate-500">
                    التحكم في العمليات التنفيذية، المعاملات المالية، وسرية التكلفة والأرباح.
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {ACTION_PRIVILEGES.map((priv) => {
                    const isEnabled = Boolean(customPermissions[priv.id]);

                    return (
                      <div
                        key={priv.id}
                        onClick={() => handleTogglePrivilege(priv.id)}
                        className={`p-3.5 rounded-xl border flex items-start justify-between cursor-pointer transition-all select-none ${
                          isEnabled
                            ? priv.isDangerous
                              ? 'border-rose-300 bg-rose-50/60 shadow-2xs'
                              : 'border-slate-900 bg-slate-50 shadow-2xs'
                            : 'border-slate-200 bg-white hover:border-slate-300'
                        }`}
                      >
                        <div className="pr-1">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-900">{priv.label}</span>
                            {priv.isDangerous && (
                              <span className="text-[10px] font-bold text-rose-700 bg-rose-100 px-1.5 py-0.2 rounded">
                                تنبيه أمني
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-slate-500 block mt-1 leading-snug">
                            {priv.description}
                          </span>
                        </div>

                        {/* Switch Style Toggle */}
                        <div
                          className={`w-10 h-5 rounded-full transition-colors relative flex items-center px-0.5 shrink-0 mt-0.5 ${
                            isEnabled
                              ? priv.isDangerous
                                ? 'bg-rose-600'
                                : 'bg-slate-900'
                              : 'bg-slate-300'
                          }`}
                        >
                          <div
                            className={`w-4 h-4 rounded-full bg-white shadow-xs transition-transform ${
                              isEnabled ? '-translate-x-5' : 'translate-x-0'
                            }`}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Modal Sticky Footer */}
            <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="text-xs text-slate-500 font-medium">
                <span>الصلاحيات المحددة: </span>
                <span className="font-bold text-slate-900">{customPermissions.allowedTabs.length} أقسام</span>
                <span aria-hidden="true"> · </span>
                <span className="font-bold text-slate-900">
                  {Object.values(customPermissions).filter((v) => v === true).length} صلاحيات تشغيلية
                </span>
              </div>

              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowPermsModal(false)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-200 rounded-xl cursor-pointer transition-colors"
                >
                  إلغاء
                </button>
                <button
                  type="button"
                  onClick={handleSaveSupervisorPerms}
                  disabled={permsModalLoading}
                  className="px-5 py-2.5 text-xs font-black text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 rounded-xl shadow-xs cursor-pointer flex items-center gap-2 transition-all active:scale-[0.98]"
                >
                  {permsModalLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>حفظ واعتماد الصلاحيات فوراً</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: Add New User Form
         ========================================================================= */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/70 backdrop-blur-xs overflow-y-auto">
          <div className="w-full max-w-lg bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200 my-6">
            <div className="p-5 sm:p-6 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="font-black text-lg flex items-center gap-2">
                  <UserPlus className="w-5 h-5 text-emerald-400" />
                  <span>إضافة حساب مشرف جديد</span>
                </h3>
                <span className="text-xs text-slate-400 font-medium">
                  تسجيل بيانات الدخول وتعيين الدور الوظيفي المعتمد
                </span>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="mx-6 mt-4 p-3.5 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs font-bold text-rose-800">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSaveUser} className="p-5 sm:p-6 space-y-4">
              <div>
                <label className="block font-bold text-xs text-slate-700 mb-1">الاسم الكامل للمشرف *</label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="مثال: م. أحمد عبد الرحمن"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-xs text-slate-700 mb-1">البريد الإلكتروني *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="supervisor@alzahraa.com"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 font-mono border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-left focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                  />
                </div>

                <div>
                  <label className="block font-bold text-xs text-slate-700 mb-1">كلمة المرور *</label>
                  <input
                    type="password"
                    required
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="6 خانات على الأقل"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 font-mono border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-left focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-xs text-slate-700 mb-1">رقم الهاتف (اختياري)</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="01012345678"
                    dir="ltr"
                    className="w-full px-3.5 py-2.5 font-mono border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-left focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                  />
                </div>

                <div>
                  <label className="block font-bold text-xs text-slate-700 mb-1">نموذج الدور الوظيفي</label>
                  <select
                    value={addPresetId}
                    onChange={(e) => handleAddPresetChange(e.target.value)}
                    className="w-full px-3 py-2.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 bg-white focus:outline-none focus:ring-2 focus:ring-slate-900/10 cursor-pointer"
                  >
                    {SUPERVISOR_PRESETS.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block font-bold text-xs text-slate-700 mb-1">المسمى الوظيفي المعتمد في المنظومة</label>
                <input
                  type="text"
                  value={addRoleTitle}
                  onChange={(e) => setAddRoleTitle(e.target.value)}
                  placeholder="مثال: مشرف مبيعات وعملاء"
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                />
              </div>

              {/* Summary of assigned permissions */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-600 space-y-1">
                <span className="font-bold text-slate-800 block">معاينة الصلاحيات المبدئية:</span>
                <p className="text-[11px] text-slate-500">
                  سيتم منح المشرف النفاذ إلى {addPermissions.allowedTabs.length} أقسام، ويمكن للمدير العام تعديل هذه الصلاحيات تفصيلياً في أي وقت.
                </p>
              </div>

              <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={modalLoading}
                  className="px-5 py-2.5 text-xs font-black text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 rounded-xl shadow-xs cursor-pointer flex items-center gap-2 transition-all active:scale-[0.98]"
                >
                  {modalLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>إنشاء الحساب واعتماد الدور</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* =========================================================================
          MODAL: Password Reset
         ========================================================================= */}
      {showPasswordModal && selectedUserForPassword && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
            <div className="p-5 bg-slate-900 text-white flex justify-between items-center">
              <div>
                <h3 className="font-black text-base flex items-center gap-2">
                  <Key className="w-4 h-4 text-emerald-400" />
                  <span>تغيير كلمة المرور</span>
                </h3>
                <span className="text-xs text-slate-400 font-medium">
                  للمستخدم: {selectedUserForPassword.fullName}
                </span>
              </div>
              <button
                onClick={() => setShowPasswordModal(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {passwordModalError && (
              <div className="mx-6 mt-4 p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-center gap-2 text-xs font-bold text-rose-800">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                <span>{passwordModalError}</span>
              </div>
            )}

            <form onSubmit={handleSavePassword} className="p-5 sm:p-6 space-y-4">
              <div>
                <label className="block font-bold text-xs text-slate-700 mb-1">
                  كلمة المرور الجديدة *
                </label>
                <div className="relative">
                  <input
                    type={showPasswordText ? 'text' : 'password'}
                    required
                    minLength={6}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="6 أحرف أو أرقام على الأقل"
                    dir="ltr"
                    className="w-full pr-3.5 pl-10 py-2.5 border border-slate-200 rounded-xl font-mono text-xs sm:text-sm font-bold text-left focus:outline-none focus:ring-2 focus:ring-slate-900/10"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPasswordText(!showPasswordText)}
                    className="absolute left-3 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showPasswordText ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowPasswordModal(false)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={passwordModalLoading}
                  className="px-5 py-2.5 text-xs font-black text-white bg-slate-900 hover:bg-slate-800 disabled:opacity-50 rounded-xl shadow-xs cursor-pointer flex items-center gap-1.5 transition-all active:scale-[0.98]"
                >
                  {passwordModalLoading && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>تحديث كلمة المرور</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
