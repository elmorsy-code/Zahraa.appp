import { RoleType, UserPermissions } from '../types/database';
import { getSupabaseClient, isSupabaseConfigured } from './supabase';

export interface UserAccount {
  id: string;
  email: string;
  username?: string;
  fullName: string;
  role: RoleType;
  roleNameAr: string;
  supervisorRoleTitle?: string;
  permissions?: UserPermissions;
  phone?: string;
  description?: string;
  avatarColor: string;
  isActive: boolean;
  createdAt?: string;
}

export const ROLE_NAMES_AR: Record<RoleType, string> = {
  admin: 'المدير العام',
  supervisor: 'مشرف',
  viewer: 'مشرف',
};

export const ADMIN_PERMISSIONS: UserPermissions = {
  allowedTabs: [
    'dashboard',
    'customers',
    'debts',
    'customer_ledgers',
    'products',
    'invoices',
    'suppliers',
    'treasury',
    'old_ledgers',
    'reports',
    'users',
    'settings',
  ],
  canAdd: true,
  canEdit: true,
  canDelete: true,
  canCollect: true,
  canDisburse: true,
  canViewCostPrices: true,
  canViewProfits: true,
  canExportPrint: true,
};

export const DEFAULT_SUPERVISOR_PERMISSIONS: UserPermissions = {
  allowedTabs: [
    'dashboard',
    'customers',
    'debts',
    'customer_ledgers',
    'products',
    'invoices',
    'suppliers',
    'treasury',
    'old_ledgers',
    'reports',
  ],
  canAdd: false,
  canEdit: false,
  canDelete: false,
  canCollect: false,
  canDisburse: false,
  canViewCostPrices: false,
  canViewProfits: false,
  canExportPrint: true,
};

export interface SupervisorRolePreset {
  id: string;
  name: string;
  description: string;
  badgeClass: string;
  permissions: UserPermissions;
}

export const SUPERVISOR_PRESETS: SupervisorRolePreset[] = [
  {
    id: 'general_supervisor',
    name: 'مشرف عام للعمليات',
    description: 'صلاحيات تشغيلية لإضافة وتعديل بيانات العملاء والأصناف والفواتير والتحصيل، مع منع حذف السجلات',
    badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-300',
    permissions: {
      allowedTabs: [
        'dashboard',
        'customers',
        'debts',
        'customer_ledgers',
        'products',
        'invoices',
        'suppliers',
        'treasury',
        'reports',
      ],
      canAdd: true,
      canEdit: true,
      canDelete: false,
      canCollect: true,
      canDisburse: false,
      canViewCostPrices: true,
      canViewProfits: true,
      canExportPrint: true,
    },
  },
  {
    id: 'sales_supervisor',
    name: 'مشرف مبيعات وعملاء',
    description: 'التركيز على إضافة ومتابعة العملاء والديون والتحصيل وكشوف الحسابات دون الوصول للمشتريات أو الخزينة العامة',
    badgeClass: 'bg-blue-100 text-blue-800 border-blue-300',
    permissions: {
      allowedTabs: ['dashboard', 'customers', 'debts', 'customer_ledgers', 'products', 'reports'],
      canAdd: true,
      canEdit: true,
      canDelete: false,
      canCollect: true,
      canDisburse: false,
      canViewCostPrices: false,
      canViewProfits: false,
      canExportPrint: true,
    },
  },
  {
    id: 'inventory_supervisor',
    name: 'مشرف مخازن ومشتريات',
    description: 'تسجيل وتعديل الأصناف والأدوية ومتابعة فواتير الشراء والموردين دون الاطلاع على الديون أو الخزينة',
    badgeClass: 'bg-teal-100 text-teal-800 border-teal-300',
    permissions: {
      allowedTabs: ['dashboard', 'products', 'invoices', 'suppliers'],
      canAdd: true,
      canEdit: true,
      canDelete: false,
      canCollect: false,
      canDisburse: false,
      canViewCostPrices: true,
      canViewProfits: false,
      canExportPrint: true,
    },
  },
  {
    id: 'treasury_supervisor',
    name: 'مشرف حسابات وخزينة',
    description: 'تسجيل ومتابعة سندات القبض والصرف، فواتير المشتريات، حركة الخزينة، والتقارير المالية',
    badgeClass: 'bg-amber-100 text-amber-800 border-amber-300',
    permissions: {
      allowedTabs: ['dashboard', 'debts', 'invoices', 'treasury', 'reports'],
      canAdd: true,
      canEdit: false,
      canDelete: false,
      canCollect: true,
      canDisburse: true,
      canViewCostPrices: true,
      canViewProfits: true,
      canExportPrint: true,
    },
  },
  {
    id: 'readonly_supervisor',
    name: 'مشرف (قراءة ومتابعة فقط)',
    description: 'تصفح كافة شاشات المنظومة والمؤشرات الحية وقراءة البيانات فقط، دون إمكانية الإضافة أو التعديل أو الحذف',
    badgeClass: 'bg-slate-100 text-slate-800 border-slate-300',
    permissions: {
      allowedTabs: [
        'dashboard',
        'customers',
        'debts',
        'customer_ledgers',
        'products',
        'invoices',
        'suppliers',
        'treasury',
        'old_ledgers',
        'reports',
      ],
      canAdd: false,
      canEdit: false,
      canDelete: false,
      canCollect: false,
      canDisburse: false,
      canViewCostPrices: false,
      canViewProfits: false,
      canExportPrint: true,
    },
  },
  {
    id: 'custom_supervisor',
    name: 'دور مخصص (يحدده المدير العام)',
    description: 'تحديد مسمى وظيفي خاص وتحديد الصلاحيات والأقسام يدوياً وفق رغبة المدير العام',
    badgeClass: 'bg-purple-100 text-purple-800 border-purple-300',
    permissions: {
      allowedTabs: ['dashboard', 'customers', 'debts'],
      canAdd: true,
      canEdit: false,
      canDelete: false,
      canCollect: false,
      canDisburse: false,
      canViewCostPrices: false,
      canViewProfits: false,
      canExportPrint: true,
    },
  },
];

export function getStoredSupervisorConfig(userId: string): { roleTitle?: string; permissions?: UserPermissions } | null {
  try {
    const raw = localStorage.getItem(`supervisor_config_${userId}`) || localStorage.getItem(`supervisor_permissions_${userId}`);
    if (raw) return JSON.parse(raw);
  } catch {}
  return null;
}

export function saveStoredSupervisorConfig(userId: string, data: { roleTitle?: string; permissions: UserPermissions }) {
  try {
    localStorage.setItem(`supervisor_config_${userId}`, JSON.stringify(data));
    localStorage.setItem(`supervisor_permissions_${userId}`, JSON.stringify(data));
  } catch {}
}

// Definition of permissions per role - only General Manager (full) and Supervisor (read-only site access)
export const ROLE_ALLOWED_TABS: Record<RoleType, string[]> = {
  admin: [
    'dashboard',
    'customers',
    'debts',
    'customer_ledgers',
    'products',
    'invoices',
    'suppliers',
    'treasury',
    'old_ledgers',
    'reports',
    'users',
    'settings',
  ],
  supervisor: [
    'dashboard',
    'customers',
    'debts',
    'customer_ledgers',
    'products',
    'invoices',
    'suppliers',
    'treasury',
    'old_ledgers',
    'reports',
    'settings',
  ],
  viewer: [
    'dashboard',
    'customers',
    'debts',
    'customer_ledgers',
    'products',
    'invoices',
    'suppliers',
    'treasury',
    'old_ledgers',
    'reports',
    'settings',
  ],
};

let cachedCurrentUser: UserAccount | null = null;
const authListeners: Set<(user: UserAccount | null) => void> = new Set();

function notifyAuthListeners() {
  authListeners.forEach((fn) => fn(cachedCurrentUser));
}

function mapProfileToUserAccount(profile: any, email: string, userMetadata?: any): UserAccount {
  const rawRole = profile.role_id || userMetadata?.role_id;
  const role: RoleType = rawRole === 'admin' ? 'admin' : 'supervisor';
  const targetId = profile.user_id || profile.id;
  const storedConfig = getStoredSupervisorConfig(targetId) || getStoredSupervisorConfig(profile.id);
  const supervisorRoleTitle =
    role === 'admin'
      ? 'المدير العام'
      : profile.description || storedConfig?.roleTitle || userMetadata?.description || 'مشرف (قراءة ومتابعة فقط)';
  // الصلاحيات المحفوظة في قاعدة البيانات هي المصدر الأساسي، ثم النسخة المحلية، ثم الافتراضي (قراءة فقط)
  const permissions =
    role === 'admin'
      ? ADMIN_PERMISSIONS
      : (profile.permissions as UserPermissions | null) || storedConfig?.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;

  return {
    id: targetId,
    email,
    username: email.split('@')[0],
    fullName: profile.full_name || userMetadata?.full_name || email,
    role,
    roleNameAr: supervisorRoleTitle,
    supervisorRoleTitle,
    permissions,
    phone: profile.phone || userMetadata?.phone || '',
    description: profile.description || userMetadata?.description || supervisorRoleTitle,
    avatarColor:
      userMetadata?.avatar_color ||
      profile.avatar_color ||
      (role === 'admin' ? 'bg-emerald-700' : 'bg-blue-700'),
    isActive: profile.is_active ?? true,
    createdAt: profile.created_at,
  };
}

export const authService = {
  getCurrentUser(): UserAccount | null {
    if (cachedCurrentUser) return cachedCurrentUser;
    try {
      const cached = localStorage.getItem('cached_current_user') || localStorage.getItem('last_active_user_profile');
      if (cached) {
        cachedCurrentUser = JSON.parse(cached);
        return cachedCurrentUser;
      }
    } catch {}
    return null;
  },

  setCurrentUser(user: UserAccount | null) {
    cachedCurrentUser = user;
    if (user) {
      try {
        localStorage.setItem('cached_current_user', JSON.stringify(user));
        localStorage.setItem('last_active_user_profile', JSON.stringify(user));
        localStorage.setItem(`user_profile_${user.id}`, JSON.stringify(user));
      } catch {}
    }
    notifyAuthListeners();
  },

  onAuthStateChange(callback: (user: UserAccount | null) => void): () => void {
    authListeners.add(callback);
    return () => authListeners.delete(callback);
  },

  async initSession(): Promise<UserAccount | null> {
    const supabase = getSupabaseClient();
    if (!supabase) {
      cachedCurrentUser = null;
      notifyAuthListeners();
      return null;
    }

    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error || !session?.user) {
        cachedCurrentUser = null;
        notifyAuthListeners();
        return null;
      }

      // Fetch profile
      const { data: profile, error: profileErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', session.user.id)
        .maybeSingle();

      // Check localStorage for saved profile overrides
      let localOverride: Partial<UserAccount> | null = null;
      try {
        const raw = localStorage.getItem(`user_profile_${session.user.id}`) || localStorage.getItem('last_active_user_profile');
        if (raw) localOverride = JSON.parse(raw);
      } catch {}

      if (profileErr || !profile) {
        // Fallback user if profile row pending
        const role = (localOverride?.role || session.user.user_metadata?.role_id || 'admin') as RoleType;
        const storedConfig = getStoredSupervisorConfig(session.user.id);
        const supervisorTitle = role === 'admin' ? 'المدير العام' : (storedConfig?.roleTitle || session.user.user_metadata?.description || 'مشرف');
        const perms = role === 'admin' ? ADMIN_PERMISSIONS : (storedConfig?.permissions || DEFAULT_SUPERVISOR_PERMISSIONS);

        cachedCurrentUser = {
          id: session.user.id,
          email: session.user.email || '',
          username: (session.user.email || '').split('@')[0],
          fullName: localOverride?.fullName || session.user.user_metadata?.full_name || session.user.email || 'المدير العام',
          role,
          roleNameAr: supervisorTitle,
          supervisorRoleTitle: supervisorTitle,
          permissions: perms,
          phone: localOverride?.phone || session.user.user_metadata?.phone || '',
          description: localOverride?.description || session.user.user_metadata?.description || supervisorTitle,
          avatarColor: localOverride?.avatarColor || session.user.user_metadata?.avatar_color || (role === 'admin' ? 'bg-emerald-700' : 'bg-blue-700'),
          isActive: true,
        };
      } else {
        if (profile.is_active === false) {
          await supabase.auth.signOut();
          cachedCurrentUser = null;
          notifyAuthListeners();
          return null;
        }
        const mapped = mapProfileToUserAccount(profile, session.user.email || '', session.user.user_metadata);
        cachedCurrentUser = {
          ...mapped,
          fullName: localOverride?.fullName || mapped.fullName,
          phone: localOverride?.phone !== undefined ? localOverride.phone : mapped.phone,
          description: localOverride?.description !== undefined ? localOverride.description : mapped.description,
          avatarColor: localOverride?.avatarColor || mapped.avatarColor,
        };
      }

      notifyAuthListeners();
      return cachedCurrentUser;
    } catch (err) {
      console.warn('Failed to get current auth session:', err);
      cachedCurrentUser = null;
      notifyAuthListeners();
      return null;
    }
  },

  async checkHasAnyUsers(): Promise<boolean> {
    const supabase = getSupabaseClient();
    if (!supabase) return false;

    try {
      const { count, error } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      if (error) {
        console.warn('Could not check profiles count:', error);
        return true; // Default to true so we don't inappropriately expose setup
      }
      return (count ?? 0) > 0;
    } catch {
      return true;
    }
  },

  async loginWithEmail(email: string, password: string): Promise<{ success: boolean; user?: UserAccount; error?: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) {
      return { success: false, error: 'الاتصال بقاعدة بيانات Supabase غير متوفر' };
    }

    try {
      const trimmedEmail = email.trim().toLowerCase();
      const { data, error } = await supabase.auth.signInWithPassword({
        email: trimmedEmail,
        password,
      });

      if (error) {
        if (error.message.includes('Invalid login credentials')) {
          return { success: false, error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
        }
        return { success: false, error: error.message };
      }

      if (!data.user) {
        return { success: false, error: 'فشل استرجاع بيانات المستخدم' };
      }

      // Check localStorage for saved profile overrides
      let localOverride: Partial<UserAccount> | null = null;
      try {
        const raw = localStorage.getItem(`user_profile_${data.user.id}`) || localStorage.getItem('last_active_user_profile');
        if (raw) localOverride = JSON.parse(raw);
      } catch {}

      // Fetch Profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', data.user.id)
        .maybeSingle();

      if (profile && profile.is_active === false) {
        await supabase.auth.signOut();
        return { success: false, error: 'هذا الحساب معطل من قبل إدارة النظام، برجاء مراجعة المدير العام' };
      }

      let userAccount: UserAccount;
      if (profile) {
        const mapped = mapProfileToUserAccount(profile, data.user.email || trimmedEmail, data.user.user_metadata);
        userAccount = {
          ...mapped,
          fullName: localOverride?.fullName || mapped.fullName,
          phone: localOverride?.phone !== undefined ? localOverride.phone : mapped.phone,
          description: localOverride?.description !== undefined ? localOverride.description : mapped.description,
          avatarColor: localOverride?.avatarColor || mapped.avatarColor,
        };
      } else {
        const role = (data.user.user_metadata?.role_id || 'admin') as RoleType;
        const storedConfig = getStoredSupervisorConfig(data.user.id);
        const supervisorTitle = role === 'admin' ? 'المدير العام' : (storedConfig?.roleTitle || data.user.user_metadata?.description || 'مشرف');
        const perms = role === 'admin' ? ADMIN_PERMISSIONS : (storedConfig?.permissions || DEFAULT_SUPERVISOR_PERMISSIONS);

        userAccount = {
          id: data.user.id,
          email: data.user.email || trimmedEmail,
          username: (data.user.email || trimmedEmail).split('@')[0],
          fullName: data.user.user_metadata?.full_name || 'المدير العام',
          role,
          roleNameAr: supervisorTitle,
          supervisorRoleTitle: supervisorTitle,
          permissions: perms,
          phone: data.user.user_metadata?.phone || '',
          description: data.user.user_metadata?.description || supervisorTitle,
          avatarColor: role === 'admin' ? 'bg-emerald-700' : 'bg-blue-700',
          isActive: true,
        };
      }

      this.setCurrentUser(userAccount);
      return { success: true, user: userAccount };
    } catch (err: any) {
      return { success: false, error: err?.message || 'حدث خطأ غير متوقع أثناء تسجيل الدخول' };
    }
  },

  async createInitialAdmin(data: {
    email: string;
    password: string;
    fullName: string;
    phone?: string;
  }): Promise<{ success: boolean; user?: UserAccount; error?: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) {
      return { success: false, error: 'الاتصال بقاعدة البيانات غير متوفر' };
    }

    try {
      const trimmedEmail = data.email.trim().toLowerCase();

      // Call secure setup RPC
      const { data: rpcRes, error: rpcErr } = await supabase.rpc('admin_create_system_user', {
        p_email: trimmedEmail,
        p_password: data.password,
        p_full_name: data.fullName.trim(),
        p_phone: data.phone?.trim() || '',
        p_role_id: 'admin',
        p_description: 'المدير العام والمؤسس الأول للنظام',
      });

      if (rpcErr) {
        // If RPC isn't found yet or errored, try standard signUp
        const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
          email: trimmedEmail,
          password: data.password,
          options: {
            data: {
              full_name: data.fullName.trim(),
              phone: data.phone?.trim() || '',
              role_id: 'admin',
              description: 'المدير العام والمؤسس الأول للنظام',
            },
          },
        });

        if (signUpErr) {
          return { success: false, error: signUpErr.message };
        }

        // Now sign in
        return await this.loginWithEmail(trimmedEmail, data.password);
      }

      // Login immediately with created credentials
      return await this.loginWithEmail(trimmedEmail, data.password);
    } catch (err: any) {
      return { success: false, error: err?.message || 'فشل إنشاء حساب المدير الأول' };
    }
  },

  async logout(): Promise<void> {
    const supabase = getSupabaseClient();
    if (supabase) {
      try {
        await supabase.auth.signOut();
      } catch (err) {
        console.warn('Sign out warning:', err);
      }
    }
    this.setCurrentUser(null);
  },

  async getProfiles(): Promise<UserAccount[]> {
    const supabase = getSupabaseClient();
    if (!supabase) return [];

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error || !data) return [];

      return data.map((p) => {
        const role: RoleType = p.role_id === 'admin' ? 'admin' : 'supervisor';
        const targetId = p.user_id || p.id;
        const storedConfig = getStoredSupervisorConfig(targetId) || getStoredSupervisorConfig(p.id);
        const supervisorRoleTitle =
          role === 'admin'
            ? 'المدير العام'
            : p.description || storedConfig?.roleTitle || 'مشرف (قراءة ومتابعة فقط)';
        const permissions =
          role === 'admin'
            ? ADMIN_PERMISSIONS
            : (p.permissions as UserPermissions | null) || storedConfig?.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;

        return {
          id: p.id,
          email: p.email || '',
          fullName: p.full_name,
          role,
          roleNameAr: supervisorRoleTitle,
          supervisorRoleTitle,
          permissions,
          phone: p.phone || '',
          description: p.description || supervisorRoleTitle,
          avatarColor: p.avatar_color || (role === 'admin' ? 'bg-emerald-700' : 'bg-blue-700'),
          isActive: p.is_active ?? true,
          createdAt: p.created_at,
        };
      });
    } catch {
      return [];
    }
  },

  async updateCurrentUserProfile(data: {
    fullName: string;
    phone?: string;
    description?: string;
    avatarColor?: string;
  }): Promise<{ success: boolean; user?: UserAccount; error?: string }> {
    const supabase = getSupabaseClient();
    let current = this.getCurrentUser();
    if (!current) {
      try {
        const raw = localStorage.getItem('cached_current_user') || localStorage.getItem('last_active_user_profile');
        if (raw) current = JSON.parse(raw);
      } catch {}
    }
    if (!current) {
      return { success: false, error: 'جلسة المستخدم غير متوفرة' };
    }

    const trimmedFullName = data.fullName.trim();
    if (!trimmedFullName) {
      return { success: false, error: 'يرجى إدخال اسم المستخدم بالكامل' };
    }

    const trimmedPhone = data.phone?.trim() || '';
    const trimmedDescription = data.description?.trim() || '';
    const selectedColor = data.avatarColor || current.avatarColor || 'bg-emerald-700';

    const updatedUser: UserAccount = {
      ...current,
      fullName: trimmedFullName,
      phone: trimmedPhone,
      description: trimmedDescription,
      avatarColor: selectedColor,
    };

    const isValidUuid = (str?: string): boolean =>
      typeof str === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);

    let authUserId: string | null = null;
    if (supabase) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user?.id) {
          authUserId = session.user.id;
        }
      } catch {}
    }

    // 1. Save immediately to localStorage with all candidate keys for rock-solid persistence
    try {
      localStorage.setItem('cached_current_user', JSON.stringify(updatedUser));
      localStorage.setItem('last_active_user_profile', JSON.stringify(updatedUser));
      localStorage.setItem(`user_profile_${current.id}`, JSON.stringify(updatedUser));
      if (authUserId) {
        localStorage.setItem(`user_profile_${authUserId}`, JSON.stringify(updatedUser));
      }
    } catch (e) {
      console.warn('Failed to save user profile to localStorage', e);
    }

    // 2. Persist to Supabase if connected
    if (supabase) {
      try {
        // A. Update Supabase auth user metadata (stores full_name, phone, description, avatar_color)
        if (authUserId) {
          await supabase.auth.updateUser({
            data: {
              full_name: trimmedFullName,
              phone: trimmedPhone,
              description: trimmedDescription,
              avatar_color: selectedColor,
            },
          });
        }

        // B. Update profiles table safely without UUID syntax errors
        let profileRowId: string | null = null;

        if (authUserId && isValidUuid(authUserId)) {
          const { data: p } = await supabase
            .from('profiles')
            .select('id')
            .eq('user_id', authUserId)
            .maybeSingle();
          if (p?.id) profileRowId = p.id;
        }

        if (!profileRowId && isValidUuid(current.id)) {
          const { data: p1 } = await supabase
            .from('profiles')
            .select('id')
            .eq('id', current.id)
            .maybeSingle();
          if (p1?.id) {
            profileRowId = p1.id;
          } else {
            const { data: p2 } = await supabase
              .from('profiles')
              .select('id')
              .eq('user_id', current.id)
              .maybeSingle();
            if (p2?.id) profileRowId = p2.id;
          }
        }

        if (profileRowId) {
          await supabase
            .from('profiles')
            .update({
              full_name: trimmedFullName,
              phone: trimmedPhone || null,
              updated_at: new Date().toISOString(),
            })
            .eq('id', profileRowId);
        } else {
          const targetUid = (authUserId && isValidUuid(authUserId)) ? authUserId : (isValidUuid(current.id) ? current.id : null);
          if (targetUid) {
            await supabase
              .from('profiles')
              .insert({
                user_id: targetUid,
                full_name: trimmedFullName,
                phone: trimmedPhone || null,
                role_id: current.role || 'admin',
                is_active: true,
                updated_at: new Date().toISOString(),
              });
          }
        }
      } catch (cloudErr) {
        console.warn('Cloud sync notice for profile:', cloudErr);
      }

      // Also try saving to app_settings as backup key
      try {
        await supabase.from('app_settings').upsert({
          key: `user_profile_${current.id}`,
          value: updatedUser,
          updated_at: new Date().toISOString(),
        });
      } catch {}
    }

    // 3. Update memory state and notify all listeners
    this.setCurrentUser(updatedUser);
    return { success: true, user: updatedUser };
  },

  async updateCurrentUserPassword(newPassword: string): Promise<{ success: boolean; error?: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) {
      return { success: false, error: 'الاتصال بقاعدة البيانات غير متوفر' };
    }
    if (!newPassword || newPassword.length < 6) {
      return { success: false, error: 'كلمة المرور يجب ألا تقل عن 6 أحرف أو أرقام' };
    }

    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) {
        return { success: false, error: error.message };
      }
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'حدث خطأ أثناء تحديث كلمة المرور' };
    }
  },

  async adminCreateUser(data: {
    email: string;
    password: string;
    fullName: string;
    role?: RoleType;
    phone?: string;
    description?: string;
    supervisorRoleTitle?: string;
    permissions?: UserPermissions;
  }): Promise<{ success: boolean; error?: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) {
      return { success: false, error: 'الاتصال بقاعدة البيانات غير متوفر' };
    }

    const roleTitle = data.supervisorRoleTitle?.trim() || data.description?.trim() || 'مشرف (قراءة ومتابعة فقط)';
    const perms = data.permissions || DEFAULT_SUPERVISOR_PERMISSIONS;

    // القيمة المخزنة في قاعدة البيانات لدور المشرف هي 'viewer' (الموجودة في جدول roles)
    // بينما الواجهة تعرضه باسم المشرف ودوره المحدد.
    const dbRole = data.role === 'admin' ? 'admin' : 'viewer';

    try {
      const { data: rpcRes, error: rpcErr } = await supabase.rpc('admin_create_system_user', {
        p_email: data.email.trim().toLowerCase(),
        p_password: data.password,
        p_full_name: data.fullName.trim(),
        p_phone: data.phone?.trim() || '',
        p_role_id: dbRole,
        p_description: roleTitle,
        p_permissions: dbRole === 'admin' ? null : perms,
      });

      if (rpcErr) {
        return { success: false, error: rpcErr.message || 'فشل إنشاء المستخدم' };
      }
      if (rpcRes && rpcRes.success === false) {
        return { success: false, error: rpcRes.message || 'فشل إنشاء المستخدم' };
      }

      // Save supervisor config locally & cloud
      const newUserId = rpcRes?.user_id || rpcRes?.id || data.email.trim().toLowerCase();
      saveStoredSupervisorConfig(newUserId, { roleTitle, permissions: perms });

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'حدث خطأ أثناء إنشاء المستخدم المشرف' };
    }
  },

  async adminUpdateSupervisorRoleAndPermissions(
    profileId: string,
    roleTitle: string,
    permissions: UserPermissions,
    userId?: string,
    profileInfo?: { fullName?: string; phone?: string }
  ): Promise<{ success: boolean; error?: string }> {
    const trimmedTitle = roleTitle.trim() || 'مشرف';

    // 1. Save locally with all possible IDs for instant lookup
    saveStoredSupervisorConfig(profileId, { roleTitle: trimmedTitle, permissions });
    if (userId) {
      saveStoredSupervisorConfig(userId, { roleTitle: trimmedTitle, permissions });
    }

    // 2. If the updated user is currently logged in, update session immediately
    const current = this.getCurrentUser();
    if (current && (current.id === profileId || current.id === userId)) {
      const updated: UserAccount = {
        ...current,
        roleNameAr: trimmedTitle,
        supervisorRoleTitle: trimmedTitle,
        permissions,
        description: trimmedTitle,
        ...(profileInfo?.fullName ? { fullName: profileInfo.fullName } : {}),
        ...(profileInfo?.phone !== undefined ? { phone: profileInfo.phone } : {}),
      };
      this.setCurrentUser(updated);
    }

    // 3. Persist to Supabase (profiles.description + profiles.permissions) عبر دالة المدير فقط
    const supabase = getSupabaseClient();
    if (supabase) {
      const { error } = await supabase.rpc('admin_update_user', {
        p_profile_id: profileId,
        p_description: trimmedTitle,
        p_permissions: permissions,
        p_full_name: profileInfo?.fullName ?? null,
        p_phone: profileInfo?.phone ?? null,
      });
      if (error) {
        return { success: false, error: error.message || 'فشل حفظ الصلاحيات في قاعدة البيانات' };
      }
    }

    return { success: true };
  },

  async adminUpdateUserPassword(userId: string, newPassword: string): Promise<{ success: boolean; error?: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) return { success: false, error: 'الاتصال غير متوفر' };

    try {
      const { error } = await supabase.rpc('admin_update_user_password', {
        p_target_user_id: userId,
        p_new_password: newPassword,
      });

      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'فشل تحديث كلمة المرور' };
    }
  },

  async adminToggleUserStatus(profileId: string, currentStatus: boolean): Promise<boolean> {
    const supabase = getSupabaseClient();
    if (!supabase) return false;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_active: !currentStatus, updated_at: new Date().toISOString() })
        .eq('id', profileId);

      return !error;
    } catch {
      return false;
    }
  },

  async adminUpdateUserRole(profileId: string, newRole: RoleType): Promise<{ success: boolean; error?: string }> {
    const supabase = getSupabaseClient();
    if (!supabase) return { success: false, error: 'الاتصال بقاعدة البيانات غير متوفر' };

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ role_id: newRole === 'admin' ? 'admin' : 'viewer', updated_at: new Date().toISOString() })
        .eq('id', profileId);

      if (error) return { success: false, error: error.message };
      return { success: true };
    } catch (err: any) {
      return { success: false, error: err?.message || 'فشل تحديث الدور' };
    }
  },

  canAccessTab(tabId: string, role?: RoleType, user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (u?.role === 'admin' || role === 'admin') return true;

    // Check custom permissions assigned by the General Manager
    if (u?.permissions?.allowedTabs && u.permissions.allowedTabs.length > 0) {
      if (u.permissions.allowedTabs.includes(tabId)) return true;
      if (tabId === 'customer_ledgers' && u.permissions.allowedTabs.includes('customers')) return true;
      if (tabId === 'suppliers' && u.permissions.allowedTabs.includes('invoices')) return true;
      if (tabId === 'old_ledgers' && u.permissions.allowedTabs.includes('treasury')) return true;
      if (tabId === 'treasury_dept' && u.permissions.allowedTabs.includes('treasury')) return true;
      return false;
    }

    const fallbackRole = role || u?.role || 'supervisor';
    const allowed = ROLE_ALLOWED_TABS[fallbackRole] || [];
    return allowed.includes(tabId);
  },

  getAllowedTabs(role?: RoleType, user?: UserAccount | null): string[] {
    const u = user || this.getCurrentUser();
    if (u?.role === 'admin' || role === 'admin') {
      return ROLE_ALLOWED_TABS.admin;
    }
    if (u?.permissions?.allowedTabs && u.permissions.allowedTabs.length > 0) {
      return u.permissions.allowedTabs;
    }
    return ROLE_ALLOWED_TABS[role || 'supervisor'] || [];
  },

  // General Manager & Supervisor Action Permissions
  canModify(role?: RoleType, user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (u?.role === 'admin' || role === 'admin') return true;
    return Boolean(u?.permissions?.canEdit || u?.permissions?.canAdd);
  },

  canAdd(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canAdd);
  },

  canEdit(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canEdit);
  },

  canDelete(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canDelete);
  },

  canCollect(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canCollect);
  },

  canDisburse(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canDisburse);
  },

  canViewCostPrices(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canViewCostPrices);
  },

  canViewProfits(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return Boolean(u.permissions?.canViewProfits);
  },

  canExportPrint(user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (!u) return false;
    if (u.role === 'admin') return true;
    return u.permissions?.canExportPrint !== false;
  },

  isSupervisor(role?: RoleType): boolean {
    return role === 'supervisor' || role === 'viewer';
  },

  isReadOnly(role?: RoleType, user?: UserAccount | null): boolean {
    const u = user || this.getCurrentUser();
    if (u?.role === 'admin' || role === 'admin') return false;
    return !Boolean(u?.permissions?.canAdd || u?.permissions?.canEdit || u?.permissions?.canCollect || u?.permissions?.canDisburse);
  },
};
