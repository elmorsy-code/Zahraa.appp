export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastItem {
  id: string;
  type: ToastType;
  message: string;
  title?: string;
  duration?: number;
}

type ToastListener = (toasts: ToastItem[]) => void;

class ToastManager {
  private toasts: ToastItem[] = [];
  private listeners: Set<ToastListener> = new Set();

  subscribe(listener: ToastListener): () => void {
    this.listeners.add(listener);
    listener(this.toasts);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach((fn) => fn([...this.toasts]));
  }

  show(message: string, type: ToastType = 'info', title?: string, duration: number = 3800): string {
    const id = Math.random().toString(36).slice(2, 9) + Date.now().toString(36);
    const newToast: ToastItem = { id, type, message, title, duration };
    
    // Max 4 toasts visible at once
    this.toasts = [...this.toasts.slice(-3), newToast];
    this.notify();

    if (duration > 0) {
      setTimeout(() => {
        this.dismiss(id);
      }, duration);
    }

    return id;
  }

  dismiss(id: string) {
    this.toasts = this.toasts.filter((t) => t.id !== id);
    this.notify();
  }

  clear() {
    this.toasts = [];
    this.notify();
  }

  success(message: string, title?: string, duration?: number) {
    return this.show(message, 'success', title, duration);
  }

  error(message: string, title?: string, duration?: number) {
    return this.show(message, 'error', title, duration);
  }

  warning(message: string, title?: string, duration?: number) {
    return this.show(message, 'warning', title, duration);
  }

  info(message: string, title?: string, duration?: number) {
    return this.show(message, 'info', title, duration);
  }
}

export const toast = new ToastManager();
export const showToast = toast;
