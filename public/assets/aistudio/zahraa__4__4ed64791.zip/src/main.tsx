import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import {ErrorBoundary} from './components/common/ErrorBoundary.tsx';
import {toast} from './lib/toast.ts';
import './index.css';
import './lib/themeManager.ts';
import './lib/settingsSave.ts';

// تحويل أي alert في المتصفح إلى تنبيه موقع مخصص وأنيق (Custom Toast)
if (typeof window !== 'undefined') {
  window.alert = (message: any) => {
    toast.warning(String(message ?? ''));
  };
}

createRoot(document.getElementById('root')!).render(
  <ErrorBoundary>
    <App />
  </ErrorBoundary>
);

